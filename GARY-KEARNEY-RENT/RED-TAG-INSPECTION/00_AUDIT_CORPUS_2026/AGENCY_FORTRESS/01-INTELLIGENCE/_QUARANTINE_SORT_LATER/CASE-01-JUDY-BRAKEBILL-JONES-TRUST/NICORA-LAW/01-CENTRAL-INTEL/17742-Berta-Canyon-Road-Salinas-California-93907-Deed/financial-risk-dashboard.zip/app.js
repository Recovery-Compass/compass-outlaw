// State Management (in-memory, NO localStorage due to sandbox restrictions)
let appState = {
  currentDate: new Date('2025-11-05'),
  cashOnHand: 14000,
  monthlyExpenses: 4000,
  nextRent: 2900,
  rentDue: new Date('2025-12-01'),
  incomeOpportunities: [
    {
      id: 1,
      name: "One Legal Refund",
      type: "Service Refund",
      amount: 25.81,
      confidence: 90,
      expected_date: new Date('2025-11-07'),
      milestone: "Refund Processing",
      milestone_date: null,
      route: "Payment Processing",
      project: "Various",
      status: "Transaction Rejected",
      evidence: "Order #26673062 rejected, $25.81 charge",
      rationale: "Order rejected, refund processing confirmed",
      actual_date: null,
      actual_amount: null,
      notes: ""
    },
    {
      id: 2,
      name: "SVS DVRO Fee Recovery (FC §6344)",
      type: "Legal Fee Award",
      amount: 14473.64,
      confidence: 85,
      expected_date: new Date('2025-11-19'),
      milestone: "November 19 Hearing",
      milestone_date: new Date('2025-11-19'),
      route: "Court Order",
      project: "SVS DVRO",
      status: "Attorney Engaged (H Bui)",
      evidence: "FC §6344 motion filed October 27, 2025",
      rationale: "Motion filed, hearing scheduled, statutory basis strong",
      actual_date: null,
      actual_amount: null,
      notes: ""
    },
    {
      id: 3,
      name: "Chase/Hart POA Settlement",
      type: "Legal Settlement",
      amount: 50000,
      confidence: 60,
      expected_date: new Date('2025-12-15'),
      milestone: "Settlement Negotiation",
      milestone_date: new Date('2025-11-15'),
      route: "Settlement Agreement",
      project: "Chase POA",
      status: "Settlement Phase",
      evidence: "2000-3000x ROI noted in portfolio status",
      rationale: "In settlement phase but formal offer not yet documented",
      actual_date: null,
      actual_amount: null,
      notes: ""
    },
    {
      id: 4,
      name: "H Bui Retainer Refund",
      type: "Retainer Return",
      amount: 7500,
      confidence: 70,
      expected_date: new Date('2025-12-31'),
      milestone: "Case Resolution",
      milestone_date: new Date('2025-12-31'),
      route: "Refund Agreement",
      project: "SVS DVRO",
      status: "Retainer Agreement Active",
      evidence: "$7,500 REFUNDABLE retainer per signed agreement",
      rationale: "Signed refundable retainer agreement, depends on case outcome",
      actual_date: null,
      actual_amount: null,
      notes: ""
    },
    {
      id: 5,
      name: "JJ Trust Property Transfer",
      type: "Trust Asset",
      amount: 400000,
      confidence: 75,
      expected_date: new Date('2026-02-01'),
      milestone: "Transfer Deed Filing",
      milestone_date: new Date('2026-01-15'),
      route: "Trust Administration",
      project: "JJ Trust",
      status: "Jonelle Beck Engaged",
      evidence: "17742 Berta Canyon Road property with Shellpoint mortgage",
      rationale: "Attorney engaged, property identified, timeline depends on trust admin",
      actual_date: null,
      actual_amount: null,
      notes: ""
    }
  ],
  sortField: 'expected_date',
  sortDirection: 'asc',
  confidenceFilter: 'all',
  viewFilter: 'all',
  currentTab: 'overview',
  dailyChecklist: {},
  forecastChecklist: {},
  accuracyLog: []
};

let nextId = 6;

// Initialize Dashboard
function initDashboard() {
  updateCurrentDate();
  updateStatusCards();
  renderPaydaysTable();
  initCharts();
  initTabs();
  initEventListeners();
  updateLastUpdated();
  renderNextPaydays();
  renderTimeline();
  updateForecasts();
}

// Date and Time Functions
function updateCurrentDate() {
  const dateEl = document.getElementById('currentDate');
  const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
  dateEl.textContent = appState.currentDate.toLocaleDateString('en-US', options);
}

function updateLastUpdated() {
  const lastUpdatedEl = document.getElementById('lastUpdated');
  lastUpdatedEl.textContent = new Date().toLocaleString();
}

function daysBetween(date1, date2) {
  const oneDay = 24 * 60 * 60 * 1000;
  return Math.round((date2 - date1) / oneDay);
}

// Status Card Updates
function updateStatusCards() {
  // Cash Position
  document.getElementById('cashPosition').textContent = formatCurrency(appState.cashOnHand);
  
  // Calculate runway
  const runwayDays = Math.floor(appState.cashOnHand / (appState.monthlyExpenses / 30));
  const riskLevel = getRiskLevel(runwayDays);
  
  document.getElementById('riskLevel').textContent = riskLevel.name;
  document.getElementById('riskLevel').className = 'card-value risk-indicator ' + riskLevel.class;
  document.getElementById('riskDays').textContent = `${runwayDays} day runway`;
  
  // Next Payment
  const daysUntilRent = daysBetween(appState.currentDate, appState.rentDue);
  document.getElementById('nextPayment').textContent = formatCurrency(appState.nextRent);
  document.getElementById('nextPaymentDate').textContent = `Rent due Dec 1 (${daysUntilRent} days)`;
  
  // Safety Score
  const safetyScore = calculateSafetyScore(runwayDays, daysUntilRent);
  document.getElementById('safetyScore').textContent = `${safetyScore}/100`;
  document.getElementById('safetyStatus').textContent = getSafetyStatus(safetyScore);
}

function getRiskLevel(days) {
  if (days >= 90) return { name: 'Normal', class: '', color: '#21808d' };
  if (days >= 60) return { name: 'Elevated', class: 'elevated', color: '#a84b2f' };
  if (days >= 30) return { name: 'Active Defense', class: 'elevated', color: '#e68161' };
  if (days >= 15) return { name: 'Crisis', class: 'crisis', color: '#c0152f' };
  return { name: 'Existential', class: 'crisis', color: '#8b0000' };
}

function calculateSafetyScore(runwayDays, daysUntilRent) {
  let score = 100;
  
  // Runway penalty
  if (runwayDays < 90) score -= (90 - runwayDays) * 0.5;
  if (runwayDays < 60) score -= 10;
  if (runwayDays < 30) score -= 20;
  
  // Upcoming payment penalty
  if (daysUntilRent < 30) score -= (30 - daysUntilRent) * 0.3;
  
  // High confidence income boost
  const highConfidenceIncome = appState.incomeOpportunities.filter(o => 
    o.confidence >= 80 && o.expected_date <= new Date(appState.currentDate.getTime() + 30*24*60*60*1000)
  );
  if (highConfidenceIncome.length > 0) score += 5;
  
  return Math.max(0, Math.min(100, Math.round(score)));
}

function getSafetyStatus(score) {
  if (score >= 80) return 'Stable';
  if (score >= 60) return 'Monitoring';
  if (score >= 40) return 'Alert';
  return 'Critical';
}

// Formatting Functions
function formatCurrency(amount) {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: 2
  }).format(amount);
}

function formatDate(date) {
  if (!date) return 'N/A';
  return date.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' });
}

// Tab Navigation
function initTabs() {
  const tabButtons = document.querySelectorAll('.tab-btn');
  tabButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      const tabName = btn.getAttribute('data-tab');
      switchTab(tabName);
    });
  });
}

function switchTab(tabName) {
  // Update buttons
  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.classList.remove('active');
    if (btn.getAttribute('data-tab') === tabName) {
      btn.classList.add('active');
    }
  });
  
  // Update panes
  document.querySelectorAll('.tab-pane').forEach(pane => {
    pane.classList.remove('active');
  });
  document.getElementById(`${tabName}-tab`).classList.add('active');
  
  appState.currentTab = tabName;
}

// Paydays Table
function renderPaydaysTable() {
  const tbody = document.getElementById('paydaysTableBody');
  tbody.innerHTML = '';
  
  let opportunities = [...appState.incomeOpportunities];
  
  // Apply filters
  if (appState.confidenceFilter !== 'all') {
    const minConfidence = parseInt(appState.confidenceFilter);
    opportunities = opportunities.filter(o => o.confidence >= minConfidence);
  }
  
  if (appState.viewFilter === 'amount') {
    opportunities.sort((a, b) => b.amount - a.amount);
  } else if (appState.viewFilter === 'fast') {
    opportunities.sort((a, b) => a.expected_date - b.expected_date);
  } else if (appState.viewFilter === 'project') {
    opportunities.sort((a, b) => a.project.localeCompare(b.project));
  } else {
    // Apply current sort
    opportunities.sort((a, b) => {
      let aVal = a[appState.sortField];
      let bVal = b[appState.sortField];
      
      if (aVal instanceof Date) {
        aVal = aVal.getTime();
        bVal = bVal.getTime();
      }
      
      if (typeof aVal === 'string') {
        return appState.sortDirection === 'asc' 
          ? aVal.localeCompare(bVal)
          : bVal.localeCompare(aVal);
      }
      
      return appState.sortDirection === 'asc' ? aVal - bVal : bVal - aVal;
    });
  }
  
  opportunities.slice(0, 10).forEach(opp => {
    const row = document.createElement('tr');
    
    const confidenceClass = getConfidenceClass(opp.confidence);
    const isReceived = opp.actual_date !== null;
    
    row.innerHTML = `
      <td><strong>${opp.name}</strong></td>
      <td>${opp.type}</td>
      <td><strong>${formatCurrency(opp.amount)}</strong></td>
      <td><span class="confidence-badge ${confidenceClass}">${opp.confidence}%</span></td>
      <td>${formatDate(opp.expected_date)}</td>
      <td>${opp.milestone || 'N/A'}</td>
      <td>${opp.project}</td>
      <td>${opp.status}</td>
      <td>
        <div class="action-buttons">
          <button class="btn-icon" onclick="editOpportunity(${opp.id})" title="Edit">✏️</button>
          <button class="btn-icon" onclick="markReceived(${opp.id})" title="${isReceived ? 'Received' : 'Mark as Received'}">${isReceived ? '✅' : '📥'}</button>
          <button class="btn-icon" onclick="viewDetails(${opp.id})" title="View Details">👁️</button>
        </div>
      </td>
    `;
    
    if (isReceived) {
      row.style.opacity = '0.6';
    }
    
    tbody.appendChild(row);
  });
}

function getConfidenceClass(confidence) {
  if (confidence >= 90) return 'confidence-90';
  if (confidence >= 70) return 'confidence-70';
  if (confidence >= 50) return 'confidence-60';
  return 'confidence-50';
}

function sortTable(field) {
  if (appState.sortField === field) {
    appState.sortDirection = appState.sortDirection === 'asc' ? 'desc' : 'asc';
  } else {
    appState.sortField = field;
    appState.sortDirection = 'asc';
  }
  renderPaydaysTable();
}

// Event Listeners
function initEventListeners() {
  // Table sorting
  document.querySelectorAll('.data-table th[data-sort]').forEach(th => {
    th.addEventListener('click', () => {
      sortTable(th.getAttribute('data-sort'));
    });
  });
  
  // Filters
  document.getElementById('confidenceFilter').addEventListener('change', (e) => {
    appState.confidenceFilter = e.target.value;
    renderPaydaysTable();
  });
  
  document.getElementById('viewFilter').addEventListener('change', (e) => {
    appState.viewFilter = e.target.value;
    renderPaydaysTable();
  });
}

// Opportunity Management
function addNewOpportunity() {
  document.getElementById('modalTitle').textContent = 'Add New Income Opportunity';
  document.getElementById('opportunityForm').reset();
  document.getElementById('opportunityForm').removeAttribute('data-edit-id');
  document.getElementById('opportunityModal').classList.add('active');
}

function editOpportunity(id) {
  const opp = appState.incomeOpportunities.find(o => o.id === id);
  if (!opp) return;
  
  document.getElementById('modalTitle').textContent = 'Edit Income Opportunity';
  document.getElementById('oppName').value = opp.name;
  document.getElementById('oppType').value = opp.type;
  document.getElementById('oppAmount').value = opp.amount;
  document.getElementById('oppConfidence').value = opp.confidence;
  document.getElementById('oppDate').value = opp.expected_date.toISOString().split('T')[0];
  document.getElementById('oppMilestone').value = opp.milestone || '';
  document.getElementById('oppProject').value = opp.project;
  document.getElementById('oppStatus').value = opp.status;
  document.getElementById('oppEvidence').value = opp.evidence;
  
  if (opp.actual_date) {
    document.getElementById('oppActualDate').value = opp.actual_date.toISOString().split('T')[0];
  }
  if (opp.actual_amount) {
    document.getElementById('oppActualAmount').value = opp.actual_amount;
  }
  
  document.getElementById('opportunityForm').setAttribute('data-edit-id', id);
  document.getElementById('opportunityModal').classList.add('active');
}

function markReceived(id) {
  const opp = appState.incomeOpportunities.find(o => o.id === id);
  if (!opp) return;
  
  if (opp.actual_date) {
    // Already received, unmark
    opp.actual_date = null;
    opp.actual_amount = null;
  } else {
    // Mark as received
    opp.actual_date = new Date();
    opp.actual_amount = opp.amount;
    appState.cashOnHand += opp.amount;
    
    // Add to accuracy log
    const daysDiff = daysBetween(opp.expected_date, opp.actual_date);
    const amountDiff = Math.abs(opp.amount - opp.actual_amount);
    const percentError = (amountDiff / opp.amount) * 100;
    
    appState.accuracyLog.push({
      name: opp.name,
      expected_date: opp.expected_date,
      actual_date: opp.actual_date,
      expected_amount: opp.amount,
      actual_amount: opp.actual_amount,
      days_diff: daysDiff,
      percent_error: percentError
    });
  }
  
  updateStatusCards();
  renderPaydaysTable();
  updateMAPE();
}

function viewDetails(id) {
  const opp = appState.incomeOpportunities.find(o => o.id === id);
  if (!opp) return;
  
  const details = `
Name: ${opp.name}
Type: ${opp.type}
Amount: ${formatCurrency(opp.amount)}
Confidence: ${opp.confidence}%
Expected Date: ${formatDate(opp.expected_date)}
Project: ${opp.project}
Status: ${opp.status}

Evidence:
${opp.evidence}

Rationale:
${opp.rationale}
${opp.actual_date ? `\n\nReceived: ${formatDate(opp.actual_date)}\nActual Amount: ${formatCurrency(opp.actual_amount)}` : ''}
  `;
  
  alert(details);
}

function closeModal() {
  document.getElementById('opportunityModal').classList.remove('active');
}

// Form submission
document.getElementById('opportunityForm').addEventListener('submit', (e) => {
  e.preventDefault();
  
  const editId = e.target.getAttribute('data-edit-id');
  const formData = {
    name: document.getElementById('oppName').value,
    type: document.getElementById('oppType').value,
    amount: parseFloat(document.getElementById('oppAmount').value),
    confidence: parseInt(document.getElementById('oppConfidence').value),
    expected_date: new Date(document.getElementById('oppDate').value),
    milestone: document.getElementById('oppMilestone').value,
    project: document.getElementById('oppProject').value,
    status: document.getElementById('oppStatus').value,
    evidence: document.getElementById('oppEvidence').value,
    rationale: document.getElementById('oppEvidence').value
  };
  
  const actualDate = document.getElementById('oppActualDate').value;
  const actualAmount = document.getElementById('oppActualAmount').value;
  
  if (actualDate) formData.actual_date = new Date(actualDate);
  if (actualAmount) formData.actual_amount = parseFloat(actualAmount);
  
  if (editId) {
    // Edit existing
    const opp = appState.incomeOpportunities.find(o => o.id === parseInt(editId));
    Object.assign(opp, formData);
  } else {
    // Add new
    formData.id = nextId++;
    formData.route = 'Manual Entry';
    formData.milestone_date = null;
    formData.notes = '';
    formData.actual_date = formData.actual_date || null;
    formData.actual_amount = formData.actual_amount || null;
    appState.incomeOpportunities.push(formData);
  }
  
  renderPaydaysTable();
  renderNextPaydays();
  renderTimeline();
  updateForecasts();
  closeModal();
});

// Charts
let runwayChart, forecastChart;

function initCharts() {
  initRunwayChart();
  initForecastChart();
}

function initRunwayChart() {
  const ctx = document.getElementById('runwayChart').getContext('2d');
  
  const data = {
    labels: ['Current', '30 Days', '60 Days', '90 Days', '120 Days'],
    datasets: [
      {
        label: 'Conservative (Expenses Only)',
        data: [
          appState.cashOnHand,
          appState.cashOnHand - appState.monthlyExpenses,
          appState.cashOnHand - appState.monthlyExpenses * 2,
          appState.cashOnHand - appState.monthlyExpenses * 3,
          appState.cashOnHand - appState.monthlyExpenses * 4
        ],
        borderColor: '#c0152f',
        backgroundColor: 'rgba(192, 21, 47, 0.1)',
        borderDash: [5, 5],
        tension: 0.1
      },
      {
        label: 'Moderate (70%+ Confidence)',
        data: calculateRunwayProjection(70),
        borderColor: '#a84b2f',
        backgroundColor: 'rgba(168, 75, 47, 0.1)',
        tension: 0.1
      },
      {
        label: 'Optimistic (All Income)',
        data: calculateRunwayProjection(0),
        borderColor: '#21808d',
        backgroundColor: 'rgba(33, 128, 141, 0.1)',
        tension: 0.1
      }
    ]
  };
  
  runwayChart = new Chart(ctx, {
    type: 'line',
    data: data,
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          position: 'top',
        },
        title: {
          display: false
        }
      },
      scales: {
        y: {
          beginAtZero: true,
          ticks: {
            callback: function(value) {
              return '$' + value.toLocaleString();
            }
          }
        }
      }
    }
  });
}

function calculateRunwayProjection(minConfidence) {
  const periods = [0, 30, 60, 90, 120];
  return periods.map(days => {
    let cash = appState.cashOnHand;
    cash -= (days / 30) * appState.monthlyExpenses;
    
    const endDate = new Date(appState.currentDate.getTime() + days * 24 * 60 * 60 * 1000);
    appState.incomeOpportunities.forEach(opp => {
      if (opp.confidence >= minConfidence && opp.expected_date <= endDate) {
        cash += opp.amount;
      }
    });
    
    return Math.max(0, cash);
  });
}

function initForecastChart() {
  const ctx = document.getElementById('forecastChart').getContext('2d');
  
  const labels = [];
  const currentDate = new Date(appState.currentDate);
  for (let i = 0; i <= 120; i += 10) {
    const date = new Date(currentDate.getTime() + i * 24 * 60 * 60 * 1000);
    labels.push(date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }));
  }
  
  const conservativeData = [];
  const optimisticData = [];
  
  for (let i = 0; i <= 120; i += 10) {
    let conservativeCash = appState.cashOnHand - (i / 30) * appState.monthlyExpenses;
    let optimisticCash = appState.cashOnHand - (i / 30) * appState.monthlyExpenses;
    
    const endDate = new Date(currentDate.getTime() + i * 24 * 60 * 60 * 1000);
    
    appState.incomeOpportunities.forEach(opp => {
      if (opp.expected_date <= endDate) {
        if (opp.confidence >= 85) {
          conservativeCash += opp.amount;
        }
        optimisticCash += opp.amount * (opp.confidence / 100);
      }
    });
    
    conservativeData.push(Math.max(0, conservativeCash));
    optimisticData.push(Math.max(0, optimisticCash));
  }
  
  forecastChart = new Chart(ctx, {
    type: 'line',
    data: {
      labels: labels,
      datasets: [
        {
          label: 'Conservative (≥85% Confidence)',
          data: conservativeData,
          borderColor: '#21808d',
          backgroundColor: 'rgba(33, 128, 141, 0.1)',
          tension: 0.3,
          fill: true
        },
        {
          label: 'Optimistic (Weighted by Confidence)',
          data: optimisticData,
          borderColor: '#32b8c6',
          backgroundColor: 'rgba(50, 184, 198, 0.05)',
          borderDash: [5, 5],
          tension: 0.3
        }
      ]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          position: 'top',
        }
      },
      scales: {
        y: {
          beginAtZero: true,
          ticks: {
            callback: function(value) {
              return '$' + value.toLocaleString();
            }
          }
        }
      }
    }
  });
}

// Next Paydays
function renderNextPaydays() {
  const container = document.getElementById('nextPaydays');
  const upcoming = [...appState.incomeOpportunities]
    .filter(o => !o.actual_date)
    .sort((a, b) => a.expected_date - b.expected_date)
    .slice(0, 3);
  
  container.innerHTML = '<h4>Next 3 Expected Payments</h4>';
  
  upcoming.forEach(opp => {
    const div = document.createElement('div');
    div.className = 'payday-item';
    div.innerHTML = `
      <div class="payday-name">${opp.name}</div>
      <div class="payday-details">
        <span>${formatCurrency(opp.amount)}</span>
        <span>${formatDate(opp.expected_date)}</span>
        <span class="confidence-badge ${getConfidenceClass(opp.confidence)}">${opp.confidence}%</span>
      </div>
    `;
    container.appendChild(div);
  });
}

// Timeline
function renderTimeline() {
  const container = document.getElementById('timelineView');
  const upcoming = [...appState.incomeOpportunities]
    .filter(o => !o.actual_date)
    .sort((a, b) => a.expected_date - b.expected_date)
    .slice(0, 8);
  
  container.innerHTML = '';
  
  upcoming.forEach(opp => {
    const div = document.createElement('div');
    div.className = 'timeline-item';
    div.innerHTML = `
      <div class="timeline-date">${formatDate(opp.expected_date)}</div>
      <div class="timeline-content">
        ${opp.name}
        <span class="timeline-amount">${formatCurrency(opp.amount)}</span>
      </div>
    `;
    container.appendChild(div);
  });
}

// Forecasts
function updateForecasts() {
  const periods = [30, 60, 90];
  
  periods.forEach(days => {
    const endDate = new Date(appState.currentDate.getTime() + days * 24 * 60 * 60 * 1000);
    let total = 0;
    
    appState.incomeOpportunities.forEach(opp => {
      if (!opp.actual_date && opp.expected_date <= endDate && opp.confidence >= 70) {
        total += opp.amount;
      }
    });
    
    document.getElementById(`forecast${days}`).textContent = formatCurrency(total);
  });
}

// MAPE Tracker
function updateMAPE() {
  if (appState.accuracyLog.length === 0) return;
  
  const totalError = appState.accuracyLog.reduce((sum, log) => sum + log.percent_error, 0);
  const mape = totalError / appState.accuracyLog.length;
  
  document.getElementById('mapeValue').textContent = mape.toFixed(1) + '%';
  
  const logContainer = document.getElementById('accuracyLog');
  logContainer.innerHTML = '';
  
  appState.accuracyLog.slice(-5).reverse().forEach(log => {
    const div = document.createElement('div');
    div.style.padding = 'var(--space-8) 0';
    div.style.borderBottom = '1px solid var(--color-card-border-inner)';
    div.innerHTML = `
      <div style="font-weight: var(--font-weight-medium);">${log.name}</div>
      <div style="font-size: var(--font-size-sm); color: var(--color-text-secondary);">
        Error: ${log.percent_error.toFixed(1)}% | Days off: ${log.days_diff}
      </div>
    `;
    logContainer.appendChild(div);
  });
}

// Workflow Functions
function resetDailyChecklist() {
  document.querySelectorAll('.daily-check').forEach(cb => cb.checked = false);
  appState.dailyChecklist = {};
}

function resetForecastChecklist() {
  document.querySelectorAll('.forecast-check').forEach(cb => cb.checked = false);
  appState.forecastChecklist = {};
}

// Export Functions
function exportToMarkdown() {
  let md = '# Financial Risk Assessment Dashboard\n\n';
  md += `**Date:** ${appState.currentDate.toLocaleDateString()}\n\n`;
  md += `## Current Position\n\n`;
  md += `- Cash on Hand: ${formatCurrency(appState.cashOnHand)}\n`;
  md += `- Monthly Expenses: ${formatCurrency(appState.monthlyExpenses)}\n`;
  md += `- Runway: ${Math.floor(appState.cashOnHand / (appState.monthlyExpenses / 30))} days\n\n`;
  md += `## Income Opportunities\n\n`;
  md += `| Name | Amount | Confidence | Expected Date | Status |\n`;
  md += `|------|--------|------------|---------------|--------|\n`;
  
  appState.incomeOpportunities.forEach(opp => {
    md += `| ${opp.name} | ${formatCurrency(opp.amount)} | ${opp.confidence}% | ${formatDate(opp.expected_date)} | ${opp.status} |\n`;
  });
  
  const blob = new Blob([md], { type: 'text/markdown' });
  downloadFile(blob, 'financial-dashboard.md');
}

function exportToJSON() {
  const data = {
    exported: new Date().toISOString(),
    current_position: {
      cash_on_hand: appState.cashOnHand,
      monthly_expenses: appState.monthlyExpenses,
      runway_days: Math.floor(appState.cashOnHand / (appState.monthlyExpenses / 30))
    },
    income_opportunities: appState.incomeOpportunities.map(opp => ({
      ...opp,
      expected_date: opp.expected_date.toISOString().split('T')[0],
      actual_date: opp.actual_date ? opp.actual_date.toISOString().split('T')[0] : null
    }))
  };
  
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
  downloadFile(blob, 'financial-dashboard.json');
}

function downloadFile(blob, filename) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

function printDashboard() {
  window.print();
}

function generateMonthlyReport() {
  alert('Monthly Report Generated\n\nThis feature would compile:\n- Forecast accuracy (MAPE)\n- Payment tracking\n- Risk level history\n- Recommendations for next month\n\nIn a full implementation, this would generate a PDF report.');
}

// Initialize on load
document.addEventListener('DOMContentLoaded', initDashboard);