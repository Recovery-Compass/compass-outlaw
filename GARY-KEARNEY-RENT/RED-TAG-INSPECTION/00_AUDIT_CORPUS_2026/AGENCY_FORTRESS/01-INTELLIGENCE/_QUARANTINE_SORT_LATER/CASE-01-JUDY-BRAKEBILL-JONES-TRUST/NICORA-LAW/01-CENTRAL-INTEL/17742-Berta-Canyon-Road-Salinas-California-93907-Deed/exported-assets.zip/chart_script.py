import plotly.graph_objects as go
import plotly.express as px
import pandas as pd
from datetime import datetime, timedelta
import numpy as np

# Create the data
current_data = {
    "date": "2025-11-05",
    "cash_position": 14000,
    "monthly_expenses": 4000,
    "days_runway": 105,
    "risk_level": "Normal"
}

income_data = [
    {"income_source": "One Legal Refund", "amount": 25.81, "expected_date": "2025-11-07", "confidence": 90},
    {"income_source": "SVS DVRO Fee Recovery", "amount": 14473.64, "expected_date": "2025-11-19", "confidence": 85},
    {"income_source": "Chase/Hart POA Settlement", "amount": 50000, "expected_date": "2025-12-15", "confidence": 60},
    {"income_source": "H Bui Retainer Refund", "amount": 7500, "expected_date": "2025-12-31", "confidence": 70},
    {"income_source": "JJ Trust Property Transfer", "amount": 400000, "expected_date": "2026-02-01", "confidence": 75}
]

# Convert to DataFrames
income_df = pd.DataFrame(income_data)
income_df['expected_date'] = pd.to_datetime(income_df['expected_date'])

# Create timeline from Nov 5, 2025 for 120 days
start_date = datetime(2025, 11, 5)
end_date = start_date + timedelta(days=120)
date_range = pd.date_range(start=start_date, end=end_date, freq='D')

# Calculate daily burn rate
daily_expenses = 4000 / 30.44  # Monthly expenses / avg days per month

# Create baseline cash flow (conservative - no income)
conservative_cash = []
optimistic_cash = []
current_cash_conservative = 14000
current_cash_optimistic = 14000

for date in date_range:
    # Conservative scenario - only burn cash
    current_cash_conservative -= daily_expenses
    conservative_cash.append(max(0, current_cash_conservative))
    
    # Optimistic scenario - include all income
    current_cash_optimistic -= daily_expenses
    
    # Add income if it occurs on this date
    for _, income in income_df.iterrows():
        if income['expected_date'].date() == date.date():
            current_cash_optimistic += income['amount']
    
    optimistic_cash.append(max(0, current_cash_optimistic))

# Create the main chart
fig = go.Figure()

# Add conservative scenario
fig.add_trace(go.Scatter(
    x=date_range,
    y=conservative_cash,
    mode='lines',
    name='Conservative',
    line=dict(color='#DB4545', width=2, dash='dash'),
    hovertemplate='%{x}<br>Cash: $%{y:,.0f}<extra></extra>'
))

# Add optimistic scenario
fig.add_trace(go.Scatter(
    x=date_range,
    y=optimistic_cash,
    mode='lines',
    name='Optimistic',
    line=dict(color='#1FB8CD', width=3),
    hovertemplate='%{x}<br>Cash: $%{y:,.0f}<extra></extra>'
))

# Add break-even line at 0
fig.add_hline(y=0, line_dash="solid", line_color="#13343B", line_width=1, opacity=0.7)

# Add income opportunities as scatter points
colors_by_confidence = {90: '#2E8B57', 85: '#2E8B57', 75: '#5D878F', 70: '#D2BA4C', 60: '#DB4545'}
sizes_by_amount = []
hover_text = []

for _, income in income_df.iterrows():
    # Calculate size based on amount (log scale for better visualization)
    size = min(50, max(10, np.log10(income['amount']) * 8))
    sizes_by_amount.append(size)
    
    # Create hover text
    hover_text.append(f"{income['income_source']}<br>${income['amount']:,.0f}<br>{income['confidence']}% confidence")

fig.add_trace(go.Scatter(
    x=income_df['expected_date'],
    y=[optimistic_cash[i] for i in range(len(date_range)) for j, income in income_df.iterrows() if date_range[i].date() == income['expected_date'].date()],
    mode='markers',
    name='Income Events',
    marker=dict(
        color=[colors_by_confidence.get(conf, '#DB4545') for conf in income_df['confidence']],
        size=sizes_by_amount,
        line=dict(width=2, color='white'),
        opacity=0.8
    ),
    text=hover_text,
    hovertemplate='%{text}<extra></extra>'
))

# Add risk bands as background shapes
fig.add_hrect(y0=0, y1=2000, fillcolor="#944454", opacity=0.1, layer="below", line_width=0)  # Existential
fig.add_hrect(y0=2000, y1=4000, fillcolor="#DB4545", opacity=0.1, layer="below", line_width=0)  # Crisis
fig.add_hrect(y0=4000, y1=8000, fillcolor="#D2BA4C", opacity=0.1, layer="below", line_width=0)  # Active Defense
fig.add_hrect(y0=8000, y1=12000, fillcolor="#964325", opacity=0.1, layer="below", line_width=0)  # Elevated
fig.add_hrect(y0=12000, y1=max(max(optimistic_cash), 50000), fillcolor="#2E8B57", opacity=0.1, layer="below", line_width=0)  # Normal

# Update layout
fig.update_layout(
    title="Financial Runway & Cash Flow Forecast",
    xaxis_title="Date",
    yaxis_title="Cash Position ($)",
    legend=dict(orientation='h', yanchor='bottom', y=1.05, xanchor='center', x=0.5),
    hovermode='x unified'
)

# Format y-axis to show dollars
fig.update_yaxes(tickformat='$,.0f')

# Update x-axis to show dates nicely
fig.update_xaxes(tickformat='%b %d')

# Save the chart
fig.write_image("financial_dashboard.png")
fig.write_image("financial_dashboard.svg", format="svg")