# Create MAPE (Mean Absolute Percentage Error) tracking template
print("FORECAST ACCURACY TRACKING (MAPE Framework)")
print("="*55)

# MAPE calculation template
def calculate_mape(actual, forecast):
    """Calculate Mean Absolute Percentage Error"""
    if actual == 0:
        return float('inf') if forecast != 0 else 0
    return abs((actual - forecast) / actual) * 100

# Create MAPE tracking template structure
mape_template = pd.DataFrame({
    'Income_Source': ['SVS DVRO Fee Recovery', 'JJ Trust Property', 'Chase Settlement', 'H Bui Refund', 'One Legal Refund'],
    'Forecast_Amount': [14473.64, 400000, 50000, 7500, 25.81],
    'Forecast_Date': ['11/19/2025', '02/01/2026', '12/15/2025', '12/31/2025', '11/07/2025'],
    'Actual_Amount': [0, 0, 0, 0, 0],  # To be filled when received
    'Actual_Date': ['', '', '', '', ''],  # To be filled when received
    'Amount_Error_%': [0, 0, 0, 0, 0],  # Calculated automatically
    'Date_Error_Days': [0, 0, 0, 0, 0],  # Calculated automatically
    'Notes': ['', '', '', '', '']  # For analysis notes
})

# Save MAPE template
mape_template.to_csv('MAPE_Accuracy_Tracker.csv', index=False)
print("✓ MAPE tracker created: 'MAPE_Accuracy_Tracker.csv'")

# Create workflow templates
print(f"\nWORKFLOW TEMPLATES:")
print("-" * 30)

daily_workflow = """
DAILY WORKFLOW (5 minutes):
1. MCP Evidence Check: Gmail scan (threats/updates), Drive files (new documents)
2. Deadline Verification: Next 7-day deadlines, milestone progress
3. Coalition Health: Attorney responses, opposition activity
4. Safety Score: Calculate current risk level (0-100)
5. Next Action: Single highest-priority task for today

Monday/Wednesday/Friday FORECASTING LOOP (15 minutes):
1. Update actual payments received vs. forecasted
2. Adjust confidence levels based on new evidence
3. Recalculate 30/60/90 day cash positions
4. Identify verification gaps requiring action
5. Update MAPE accuracy tracker

Month-End ACCURACY AUDIT (30 minutes):
1. Calculate MAPE scores for all predictions
2. Analyze forecast errors and root causes
3. Adjust future confidence calculations
4. Update risk band thresholds if needed
5. Document lessons learned for next month
"""

print(daily_workflow)

# Request list template based on evidence gaps
print("REQUEST LIST BY COUNTERPARTY:")
print("-" * 35)

request_list = {
    "H Bui Law Firm (melody@hbuilaw.com)": {
        "due_date": "November 8, 2025",
        "requests": [
            "November 19 hearing status confirmation",
            "Fee recovery collection procedures",
            "Retainer refund timeline clarification"
        ]
    },
    "Jonelle Beck (jcbecklaw@gmail.com)": {
        "due_date": "November 15, 2025", 
        "requests": [
            "Trust transfer deed completion",
            "Shellpoint mortgage status update",
            "Property transfer timeline"
        ]
    },
    "One Legal (noreply@onelegal.com)": {
        "due_date": "November 7, 2025",
        "requests": [
            "Order #26673062 refund processing",
            "Case rejection explanation",
            "Account credit confirmation"
        ]
    }
}

for party, details in request_list.items():
    print(f"\n{party}:")
    print(f"  Due Date: {details['due_date']}")
    print(f"  Requests:")
    for req in details['requests']:
        print(f"    - {req}")

print()