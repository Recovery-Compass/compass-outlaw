# Create comprehensive forecast framework based on email evidence
print("POTENTIAL INCOME STREAMS - EVIDENCE-BASED ANALYSIS")
print("="*60)

# Income opportunities from Gmail evidence analysis
income_opportunities = [
    {
        "name": "SVS DVRO Fee Recovery (FC §6344)",
        "type": "Legal Fee Award",
        "potential_amount": 14473.64,
        "confidence": 85,
        "expected_date": datetime(2025, 11, 19),
        "milestone": "November 19 Hearing",
        "milestone_date": datetime(2025, 11, 19),
        "route": "Court Award",
        "project": "SVS DVRO",
        "status": "Attorney Engaged (H Bui)",
        "evidence": "FC §6344 motion filed October 27, 2025",
        "rationale": "Mandatory fee award for prevailing DVRO party; strong legal basis"
    },
    {
        "name": "H Bui Retainer Refund",
        "type": "Retainer Return",
        "potential_amount": 7500,
        "confidence": 70,
        "expected_date": datetime(2025, 12, 31),
        "milestone": "Case Resolution",
        "milestone_date": datetime(2025, 12, 31),
        "route": "Attorney Refund",
        "project": "SVS DVRO",
        "status": "Retainer Agreement Active",
        "evidence": "$7,500 REFUNDABLE retainer per signed agreement",
        "rationale": "Refundable retainer per written agreement terms"
    },
    {
        "name": "JJ Trust Property Transfer",
        "type": "Trust Asset",
        "potential_amount": 400000,  # Conservative estimate based on CA property values
        "confidence": 75,
        "expected_date": datetime(2026, 2, 1),
        "milestone": "Transfer Deed Filing",
        "milestone_date": datetime(2025, 12, 3),
        "route": "Probate Resolution",
        "project": "JJ Trust",
        "status": "Jonelle Beck Engaged",
        "evidence": "17742 Berta Canyon Road, Salinas property with Shellpoint mortgage",
        "rationale": "Successor trustee rights to mother's property, CFPB pressure applied"
    },
    {
        "name": "Chase/Hart POA Settlement",
        "type": "Legal Settlement",
        "potential_amount": 50000,  # Estimate based on 2000-3000x ROI mentioned
        "confidence": 60,
        "expected_date": datetime(2025, 12, 15),
        "milestone": "Settlement Negotiation",
        "milestone_date": datetime(2025, 11, 30),
        "route": "Settlement Agreement",
        "project": "Chase POA",
        "status": "Settlement Phase",
        "evidence": "2000-3000x ROI noted in portfolio status",
        "rationale": "Settlement phase with strong ROI potential"
    },
    {
        "name": "One Legal Refund",
        "type": "Service Refund",
        "potential_amount": 25.81,
        "confidence": 90,
        "expected_date": datetime(2025, 11, 7),
        "milestone": "Refund Processing",
        "milestone_date": datetime(2025, 11, 7),
        "route": "Service Provider",
        "project": "Various",
        "status": "Transaction Rejected",
        "evidence": "Order #26673062 rejected, $25.81 charge",
        "rationale": "Service not delivered due to court rejection"
    }
]

# Convert to DataFrame for analysis
df = pd.DataFrame(income_opportunities)

# Sort by confidence and expected date
df_sorted = df.sort_values(['confidence', 'expected_date'], ascending=[False, True])

print("\nTOP 10 NEXT PAYDAYS (Sorted by Confidence & Timeline):")
print("-" * 120)
print(f"{'Name':<35} {'Type':<15} {'Amount':<12} {'Conf%':<5} {'Exp Date':<12} {'Status':<20}")
print("-" * 120)

for idx, row in df_sorted.iterrows():
    print(f"{row['name'][:34]:<35} {row['type'][:14]:<15} ${row['potential_amount']:>10,.0f} {row['confidence']:>3}% {row['expected_date'].strftime('%m/%d/%Y'):<12} {row['status'][:19]:<20}")

print()