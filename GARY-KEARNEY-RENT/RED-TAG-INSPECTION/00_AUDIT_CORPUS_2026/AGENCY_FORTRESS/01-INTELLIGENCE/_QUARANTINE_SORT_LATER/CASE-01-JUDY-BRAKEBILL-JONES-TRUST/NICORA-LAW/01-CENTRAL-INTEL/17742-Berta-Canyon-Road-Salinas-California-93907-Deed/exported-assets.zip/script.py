# Set up financial analysis for Eric Jones personal risk assessment
import pandas as pd
import numpy as np
from datetime import datetime, date, timedelta
from dateutil.relativedelta import relativedelta

# Current date context
today = datetime(2025, 11, 5)
print(f"FINANCIAL RISK ASSESSMENT FOR ERIC JONES")
print(f"Analysis Date: {today.strftime('%B %d, %Y')}")
print("="*60)

# Current financial position from seed facts
cash_on_hand = 14000
next_rent = 2900
rent_due_date = datetime(2025, 12, 1)

# Calculate days until next rent
days_to_rent = (rent_due_date - today).days
print(f"\nCURRENT FINANCIAL POSITION:")
print(f"Cash on Hand: ${cash_on_hand:,}")
print(f"Next Rent: ${next_rent:,} (Due: {rent_due_date.strftime('%B %d, %Y')})")
print(f"Days Until Rent Due: {days_to_rent}")

# Basic expense structure based on rent level (assuming standard ratios)
monthly_rent = 2900
estimated_monthly_expenses = monthly_rent + 1100  # Basic utilities, food, etc
print(f"Estimated Monthly Expenses: ${estimated_monthly_expenses:,}")

# Calculate runway
current_runway_days = (cash_on_hand / estimated_monthly_expenses) * 30
print(f"Current Cash Runway: {current_runway_days:.1f} days")

# Risk band classification based on runway
def classify_risk_band(runway_days):
    if runway_days >= 90:
        return "Normal", "green"
    elif runway_days >= 60:
        return "Elevated", "yellow"
    elif runway_days >= 30:
        return "Active Defense", "orange"
    elif runway_days >= 15:
        return "Crisis", "red"
    else:
        return "Existential", "red"

risk_band, risk_color = classify_risk_band(current_runway_days)
print(f"RISK CLASSIFICATION: {risk_band}")
print()