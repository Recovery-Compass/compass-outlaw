# Create comprehensive dashboard template with MAPE tracking
print("PERSONAL FINANCIAL DASHBOARD TEMPLATE")
print("="*60)

# Create the main tracking table structure
dashboard_data = {
    'Name': [],
    'Type': [],
    'Amount': [],
    'Confidence_%': [],
    'Expected_Pay_Date': [],
    'Next_Milestone': [],
    'Milestone_Date': [],
    'Route': [],
    'Project': [],
    'Status': [],
    'Evidence_Links': [],
    'Confidence_Rationale': [],
    'Actual_Pay_Date': [],
    'Actual_Amount': [],
    'Notes': []
}

# Add income opportunities to dashboard
for opp in income_opportunities:
    dashboard_data['Name'].append(opp['name'])
    dashboard_data['Type'].append(opp['type'])
    dashboard_data['Amount'].append(opp['potential_amount'])
    dashboard_data['Confidence_%'].append(opp['confidence'])
    dashboard_data['Expected_Pay_Date'].append(opp['expected_date'].strftime('%m/%d/%Y'))
    dashboard_data['Next_Milestone'].append(opp['milestone'])
    dashboard_data['Milestone_Date'].append(opp['milestone_date'].strftime('%m/%d/%Y'))
    dashboard_data['Route'].append(opp['route'])
    dashboard_data['Project'].append(opp['project'])
    dashboard_data['Status'].append(opp['status'])
    dashboard_data['Evidence_Links'].append(opp['evidence'])
    dashboard_data['Confidence_Rationale'].append(opp['rationale'])
    dashboard_data['Actual_Pay_Date'].append("")  # To be filled when received
    dashboard_data['Actual_Amount'].append("")    # To be filled when received
    dashboard_data['Notes'].append("")           # For ongoing updates

# Create DataFrame
forecast_df = pd.DataFrame(dashboard_data)

# Save to CSV for dashboard use
forecast_df.to_csv('Personal_Financial_Dashboard.csv', index=False)
print("✓ Dashboard CSV created: 'Personal_Financial_Dashboard.csv'")

# Create views
print(f"\nDASHBOARD VIEWS:")
print("-" * 40)

# Top 3 by amount
print("1. AMOUNT-MAXIMIZING VIEW (Top 3):")
top_amounts = forecast_df.nlargest(3, 'Amount')[['Name', 'Amount', 'Expected_Pay_Date', 'Confidence_%']]
print(top_amounts.to_string(index=False))

print(f"\n2. FAST-TO-CLOSE VIEW (Next 30 days, >70% confidence):")
fast_close = forecast_df[
    (pd.to_datetime(forecast_df['Expected_Pay_Date']) <= today + timedelta(days=30)) &
    (forecast_df['Confidence_%'] >= 70)
][['Name', 'Amount', 'Expected_Pay_Date', 'Confidence_%']]
print(fast_close.to_string(index=False))

print(f"\n3. PROJECT PORTALS VIEW:")
project_summary = forecast_df.groupby('Project').agg({
    'Amount': 'sum',
    'Confidence_%': 'mean',
    'Name': 'count'
}).round(1)
project_summary.columns = ['Total_Amount', 'Avg_Confidence', 'Count']
print(project_summary.to_string())

print()