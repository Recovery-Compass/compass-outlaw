# Calculate 30/60/90 day forecasts
print("CASH FLOW FORECASTS (Evidence-Based):")
print("="*50)

# Time periods for analysis
periods = [30, 60, 90]
period_dates = [today + timedelta(days=p) for p in periods]

print(f"{'Period':<10} {'End Date':<12} {'Potential Income':<15} {'High Conf Only':<15} {'Net Position':<15}")
print("-" * 75)

for i, period in enumerate(periods):
    end_date = period_dates[i]
    
    # Calculate potential income within this period
    period_income = 0
    high_conf_income = 0
    
    for _, row in df.iterrows():
        if row['expected_date'] <= end_date:
            period_income += row['potential_amount']
            if row['confidence'] >= 75:
                high_conf_income += row['potential_amount']
    
    # Calculate monthly expenses for period
    months_in_period = period / 30
    period_expenses = estimated_monthly_expenses * months_in_period
    
    # Net positions
    net_potential = cash_on_hand + period_income - period_expenses
    net_conservative = cash_on_hand + high_conf_income - period_expenses
    
    print(f"{period:<10} {end_date.strftime('%m/%d/%Y'):<12} ${period_income:>12,.0f} ${high_conf_income:>12,.0f} ${net_conservative:>12,.0f}")

print(f"\nMonthly Burn Rate: ${estimated_monthly_expenses:,}")

# Calculate earliest realistic income date
earliest_income = df_sorted.iloc[0]
print(f"\nEARLIEST REALISTIC INCOME:")
print(f"Source: {earliest_income['name']}")
print(f"Amount: ${earliest_income['potential_amount']:,.2f}")
print(f"Expected: {earliest_income['expected_date'].strftime('%B %d, %Y')}")
print(f"Confidence: {earliest_income['confidence']}%")
print(f"Days from today: {(earliest_income['expected_date'] - today).days}")

print()