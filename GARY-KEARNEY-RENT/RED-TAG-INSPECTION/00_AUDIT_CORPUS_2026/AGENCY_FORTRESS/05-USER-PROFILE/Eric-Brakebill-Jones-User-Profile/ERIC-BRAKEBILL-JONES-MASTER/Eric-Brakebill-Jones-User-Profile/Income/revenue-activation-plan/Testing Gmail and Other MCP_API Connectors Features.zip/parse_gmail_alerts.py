#!/usr/bin/env python3
"""
Gmail Alert Parser - Recovery Compass Priority Contacts
Parses Gmail MCP output and alerts on new emails from Anuar, Rudy, Sara
"""

import json
import os
from datetime import datetime

def check_emails(file_path, contact_name, priority):
    """Check for new emails from a specific contact"""
    if not os.path.exists(file_path):
        print(f"⚠️  No data file found for {contact_name}: {file_path}")
        return
    
    try:
        with open(file_path, 'r') as f:
            content = f.read()
            
        # Try to find JSON in the output (MCP wraps it)
        if 'the results was saved to the file' in content:
            # Extract the actual JSON file path
            import re
            match = re.search(r'/tmp/manus-mcp/mcp_result_[a-f0-9]+\.json', content)
            if match:
                json_file = match.group(0)
                if os.path.exists(json_file):
                    with open(json_file, 'r') as jf:
                        data = json.load(jf)
                else:
                    print(f"⚠️  JSON file not found: {json_file}")
                    return
            else:
                print(f"⚠️  Could not extract JSON path from {file_path}")
                return
        else:
            # Try to parse directly
            try:
                data = json.loads(content)
            except json.JSONDecodeError:
                print(f"⚠️  Could not parse JSON from {file_path}")
                return
        
        # Check if any emails found
        email_count = 0
        if isinstance(data, list):
            email_count = len(data)
            emails = data
        elif isinstance(data, dict) and 'messages' in data:
            email_count = len(data['messages'])
            emails = data['messages']
        else:
            emails = []
        
        if email_count > 0:
            print(f"\n{'='*60}")
            print(f"🚨 {priority} PRIORITY: NEW EMAIL FROM {contact_name}")
            print(f"{'='*60}")
            for i, msg in enumerate(emails[:5], 1):  # Show max 5 emails
                subject = msg.get('subject', 'No subject')
                date = msg.get('date', 'Unknown date')
                snippet = msg.get('snippet', '')[:150]
                
                print(f"\nEmail #{i}:")
                print(f"  Subject: {subject}")
                print(f"  Date: {date}")
                print(f"  Preview: {snippet}...")
                print(f"  {'─'*58}")
            print(f"\nTotal emails found: {email_count}")
            print(f"{'='*60}\n")
        else:
            print(f"✓ No new emails from {contact_name}")
    
    except Exception as e:
        print(f"⚠️  Error checking {contact_name}: {str(e)}")

def main():
    """Main function to check all priority contacts"""
    print(f"\n{'='*60}")
    print(f"Gmail Auto-Check - {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"{'='*60}\n")
    
    # Check all contacts (ordered by priority)
    check_emails('/tmp/anuar_emails.json', 'ANUAR RAMIREZ (Ex Parte Filing)', 'HIGH')
    check_emails('/tmp/sara_emails.json', 'SARA MEMARI (H Bui Law Firm)', 'MEDIUM')
    check_emails('/tmp/rudy_emails.json', 'RUDY GARCIA (Whittier Partnership)', 'LOW')
    
    print(f"\n{'='*60}")
    print("Gmail auto-check complete")
    print(f"{'='*60}\n")

if __name__ == "__main__":
    main()
