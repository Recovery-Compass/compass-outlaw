# Zapier Automation Setup Guide - Gmail Monitoring
**Date:** November 7, 2025, 9:00 PM PT  
**Objective:** Auto-monitor Gmail for priority contacts (Anuar, Rudy, Sara)

---

## ZAPIER MCP STATUS

**Available Tools:**
- `gmail_find_email` - Search Gmail messages
- `gmail_send_email` - Send emails
- `gmail_create_draft` - Create draft emails
- `gmail_add_label_to_email` - Organize emails
- `google_sheets_create_spreadsheet_row` - Add to Priority Dashboard
- `google_sheets_lookup_spreadsheet_row` - Read Priority Dashboard

**Current Limitation:**
- Zapier MCP requires `instructions` parameter (natural language description)
- Cannot execute direct automation workflows via MCP
- **Solution:** Use Zapier web interface to create Zaps manually

---

## AUTOMATION ARCHITECTURE

### Workflow 1: Anuar Email Alert (Ex Parte Filing)

**Trigger:** New email in Gmail
- **From:** anuarramirezmedina@gmail.com OR anuar@sevenhillslaw.com
- **Subject contains:** ex parte OR filing OR rejection OR court

**Actions:**
1. **Add row to Google Sheets** (Priority Dashboard)
   - Column A: Date received
   - Column B: From (Anuar Ramirez)
   - Column C: Subject line
   - Column D: Status (New)
   - Column E: Action (Review ex parte filing status)
   
2. **Send notification** (Optional: Slack, Discord, SMS)
   - Message: "🚨 Anuar responded - Ex Parte Filing Update"
   - Link to email

### Workflow 2: Rudy Garcia Email Alert (Whittier Partnership)

**Trigger:** New email in Gmail
- **From:** RGarcia@whittierfirstday.org
- **Subject contains:** Whittier OR Randall OR meeting OR partnership

**Actions:**
1. **Add row to Google Sheets** (Priority Dashboard)
   - Column A: Date received
   - Column B: From (Rudy Garcia)
   - Column C: Subject line
   - Column D: Status (New)
   - Column E: Action (Review Whittier partnership update)

### Workflow 3: Sara Memari Email Alert (H Bui Law Firm)

**Trigger:** New email in Gmail
- **From:** sara@hbuilaw.com
- **Subject contains:** Kirk OR Nuha OR case OR hearing OR Nov 19

**Actions:**
1. **Add row to Google Sheets** (Priority Dashboard)
   - Column A: Date received
   - Column B: From (Sara Memari)
   - Column C: Subject line
   - Column D: Status (New)
   - Column E: Action (Review H Bui Law Firm update)

---

## MANUAL SETUP INSTRUCTIONS (Zapier Web Interface)

### Step 1: Create Priority Dashboard (Google Sheets)

1. Go to: https://sheets.google.com
2. Create new spreadsheet: "Recovery Compass Priority Dashboard"
3. Add columns:
   - A: Date
   - B: From
   - C: Subject
   - D: Status
   - E: Action
   - F: Notes

### Step 2: Create Zap #1 (Anuar Email Alert)

1. Go to: https://zapier.com/app/zaps
2. Click "Create Zap"
3. **Trigger:**
   - App: Gmail
   - Event: New Email Matching Search
   - Search String: `from:anuarramirezmedina@gmail.com OR from:anuar@sevenhillslaw.com`
4. **Action:**
   - App: Google Sheets
   - Event: Create Spreadsheet Row
   - Spreadsheet: Recovery Compass Priority Dashboard
   - Worksheet: Sheet1
   - Row Data:
     - Date: `{{trigger.date}}`
     - From: `Anuar Ramirez`
     - Subject: `{{trigger.subject}}`
     - Status: `New`
     - Action: `Review ex parte filing status`
5. **Test & Turn On**

### Step 3: Create Zap #2 (Rudy Garcia Email Alert)

1. Click "Create Zap"
2. **Trigger:**
   - App: Gmail
   - Event: New Email Matching Search
   - Search String: `from:RGarcia@whittierfirstday.org`
3. **Action:**
   - App: Google Sheets
   - Event: Create Spreadsheet Row
   - Spreadsheet: Recovery Compass Priority Dashboard
   - Worksheet: Sheet1
   - Row Data:
     - Date: `{{trigger.date}}`
     - From: `Rudy Garcia`
     - Subject: `{{trigger.subject}}`
     - Status: `New`
     - Action: `Review Whittier partnership update`
4. **Test & Turn On**

### Step 3: Create Zap #3 (Sara Memari Email Alert)

1. Click "Create Zap"
2. **Trigger:**
   - App: Gmail
   - Event: New Email Matching Search
   - Search String: `from:sara@hbuilaw.com`
3. **Action:**
   - App: Google Sheets
   - Event: Create Spreadsheet Row
   - Spreadsheet: Recovery Compass Priority Dashboard
   - Worksheet: Sheet1
   - Row Data:
     - Date: `{{trigger.date}}`
     - From: `Sara Memari`
     - Subject: `{{trigger.subject}}`
     - Status: `New`
     - Action: `Review H Bui Law Firm update`
4. **Test & Turn On**

---

## ALTERNATIVE: GMAIL MCP AUTO-CHECK (Manus AI)

**Since Zapier MCP requires manual setup, use Gmail MCP directly:**

### Auto-Check Script (Run Every 15 Minutes)

```bash
#!/bin/bash
# File: /home/ubuntu/gmail_auto_check.sh

# Check for Anuar emails
manus-mcp-cli tool call gmail_search_messages --server gmail --input '{"query": "from:anuarramirezmedina@gmail.com OR from:anuar@sevenhillslaw.com after:2025/11/07", "maxResults": 5}' > /tmp/anuar_emails.json

# Check for Rudy emails
manus-mcp-cli tool call gmail_search_messages --server gmail --input '{"query": "from:RGarcia@whittierfirstday.org after:2025/11/07", "maxResults": 5}' > /tmp/rudy_emails.json

# Check for Sara emails
manus-mcp-cli tool call gmail_search_messages --server gmail --input '{"query": "from:sara@hbuilaw.com after:2025/11/07", "maxResults": 5}' > /tmp/sara_emails.json

# Parse and alert if new emails found
python3 /home/ubuntu/parse_gmail_alerts.py
```

### Parse Script (Extract New Emails)

```python
# File: /home/ubuntu/parse_gmail_alerts.py
import json
import os
from datetime import datetime

def check_emails(file_path, contact_name):
    if not os.path.exists(file_path):
        return
    
    with open(file_path, 'r') as f:
        data = json.load(f)
    
    # Check if any emails found
    if 'messages' in data and len(data['messages']) > 0:
        print(f"🚨 NEW EMAIL FROM {contact_name}")
        for msg in data['messages']:
            print(f"  - Subject: {msg.get('subject', 'No subject')}")
            print(f"  - Date: {msg.get('date', 'Unknown date')}")
            print(f"  - Snippet: {msg.get('snippet', '')[:100]}")
            print()

# Check all contacts
check_emails('/tmp/anuar_emails.json', 'ANUAR RAMIREZ')
check_emails('/tmp/rudy_emails.json', 'RUDY GARCIA')
check_emails('/tmp/sara_emails.json', 'SARA MEMARI')
```

### Cron Job (Run Every 15 Minutes)

```bash
# Add to crontab: crontab -e
*/15 * * * * /home/ubuntu/gmail_auto_check.sh
```

---

## WEEKEND/AFTER-HOURS VALIDITY CHECK (PFV v3)

**Current Time:** Friday, November 7, 2025, 9:00 PM PT

**Weekend/After-Hours Considerations:**
- ❌ **Courts closed** - No ex parte filing until Monday 10:00 AM
- ❌ **Law offices closed** - Anuar/Sara unlikely to respond until Monday
- ✅ **Gmail monitoring active** - Emails will be captured if sent
- ✅ **Zapier automation** - Works 24/7, including weekends

**Confidence Labels:**
- **TIER 1 (90-100%):** Gmail MCP will capture emails from Anuar/Rudy/Sara
- **TIER 2 (70-89%):** Zapier automation will work if manually set up
- **TIER 3 (50-69%):** Anuar/Sara will respond over weekend (unlikely, but possible)
- **TIER 4 (<50%):** Ex parte can be filed over weekend (NO - courts closed)

**Hedging:**
- "Zapier automation will capture emails IF manually set up via web interface"
- "Gmail MCP auto-check will work IF cron job is configured"
- "Anuar/Sara may respond over weekend, but unlikely given Friday 9 PM timing"

---

## IMMEDIATE ACTIONS (TONIGHT - 9:00 PM PT)

### Option A: Manual Zapier Setup (15-30 minutes)
1. ⏳ Create Priority Dashboard in Google Sheets
2. ⏳ Create 3 Zaps (Anuar, Rudy, Sara)
3. ⏳ Test each Zap (send test email, verify capture)
4. ⏳ Turn on all Zaps

**Pros:** Fully automated, works 24/7  
**Cons:** Requires manual web interface setup

### Option B: Gmail MCP Auto-Check (5-10 minutes)
1. ⏳ Create `/home/ubuntu/gmail_auto_check.sh` script
2. ⏳ Create `/home/ubuntu/parse_gmail_alerts.py` script
3. ⏳ Add cron job (run every 15 minutes)
4. ⏳ Test script manually

**Pros:** Quick setup, no web interface needed  
**Cons:** Requires cron job configuration

### Option C: Manual Gmail Check (0 minutes)
1. ⏳ Check Gmail manually every 2-4 hours
2. ⏳ Look for emails from Anuar, Rudy, Sara
3. ⏳ Add to Priority Dashboard manually

**Pros:** No setup required  
**Cons:** Manual effort, not automated

---

## RECOMMENDATION (PFV v3 Confidence: 85%)

**Use Option B (Gmail MCP Auto-Check) for immediate activation:**
- ✅ Quick setup (5-10 minutes)
- ✅ No web interface required
- ✅ Works over weekend
- ✅ Can be upgraded to Option A later

**Defer Option A (Zapier Web Setup) to Monday:**
- ⏳ More robust long-term solution
- ⏳ Requires focused setup time (15-30 minutes)
- ⏳ Better for ongoing monitoring

---

## EXECUTION STATUS

**Current Status:** Zapier MCP cannot execute automation directly (requires `instructions` parameter)

**Next Steps:**
1. ⏳ Create Gmail MCP auto-check scripts (Option B)
2. ⏳ Test scripts manually
3. ⏳ Set up cron job (run every 15 minutes)
4. ⏳ Monitor for Anuar/Rudy/Sara emails over weekend

**Expected Outcome:**
- Gmail monitoring active by 10:00 PM PT tonight
- Emails from Anuar/Rudy/Sara will be captured and alerted
- Manual Zapier setup can be done Monday morning

---

**END OF ZAPIER AUTOMATION SETUP GUIDE**
