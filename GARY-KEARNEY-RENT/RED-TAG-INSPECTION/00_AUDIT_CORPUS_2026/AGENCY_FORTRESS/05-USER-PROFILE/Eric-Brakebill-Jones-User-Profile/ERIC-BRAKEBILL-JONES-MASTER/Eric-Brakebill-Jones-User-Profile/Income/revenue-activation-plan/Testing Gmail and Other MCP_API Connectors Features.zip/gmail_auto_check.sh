#!/bin/bash
# Gmail Auto-Check Script - Recovery Compass Priority Contacts
# Run every 15 minutes to monitor for Anuar, Rudy, Sara emails

# Check for Anuar emails (ex parte filing)
echo "Checking Anuar Ramirez emails..."
manus-mcp-cli tool call gmail_search_messages --server gmail --input '{"query": "from:anuarramirezmedina@gmail.com OR from:anuar@sevenhillslaw.com after:2025/11/07", "maxResults": 5}' > /tmp/anuar_emails.json 2>&1

# Check for Rudy emails (Whittier partnership)
echo "Checking Rudy Garcia emails..."
manus-mcp-cli tool call gmail_search_messages --server gmail --input '{"query": "from:RGarcia@whittierfirstday.org after:2025/11/07", "maxResults": 5}' > /tmp/rudy_emails.json 2>&1

# Check for Sara emails (H Bui Law Firm)
echo "Checking Sara Memari emails..."
manus-mcp-cli tool call gmail_search_messages --server gmail --input '{"query": "from:sara@hbuilaw.com after:2025/11/07", "maxResults": 5}' > /tmp/sara_emails.json 2>&1

# Parse and alert if new emails found
python3 /home/ubuntu/parse_gmail_alerts.py

echo "Gmail auto-check complete: $(date)"
