#!/bin/bash
# Gmail Auto-Check Script - Recovery Compass Priority Contacts (FIXED)
# Run every 15 minutes to monitor for Anuar, Rudy, Sara emails

export MANUS_MCP_RESULT_FILEPATH="/tmp/mcp_results"
mkdir -p "$MANUS_MCP_RESULT_FILEPATH"

echo "============================================================"
echo "Gmail Auto-Check - $(date)"
echo "============================================================"

# Check for Anuar emails (ex parte filing)
echo ""
echo "Checking Anuar Ramirez emails..."
manus-mcp-cli tool call gmail_search_messages --server gmail --input '{"query": "from:anuarramirezmedina@gmail.com OR from:anuar@sevenhillslaw.com after:2025/11/07", "maxResults": 5}' 2>&1 | grep -E "(Subject:|From:|Date:|Snippet:)" | head -20

# Check for Rudy emails (Whittier partnership)
echo ""
echo "Checking Rudy Garcia emails..."
manus-mcp-cli tool call gmail_search_messages --server gmail --input '{"query": "from:RGarcia@whittierfirstday.org after:2025/11/07", "maxResults": 5}' 2>&1 | grep -E "(Subject:|From:|Date:|Snippet:)" | head -20

# Check for Sara emails (H Bui Law Firm)
echo ""
echo "Checking Sara Memari emails..."
manus-mcp-cli tool call gmail_search_messages --server gmail --input '{"query": "from:sara@hbuilaw.com after:2025/11/07", "maxResults": 5}' 2>&1 | grep -E "(Subject:|From:|Date:|Snippet:)" | head -20

echo ""
echo "============================================================"
echo "Gmail auto-check complete: $(date)"
echo "============================================================"
