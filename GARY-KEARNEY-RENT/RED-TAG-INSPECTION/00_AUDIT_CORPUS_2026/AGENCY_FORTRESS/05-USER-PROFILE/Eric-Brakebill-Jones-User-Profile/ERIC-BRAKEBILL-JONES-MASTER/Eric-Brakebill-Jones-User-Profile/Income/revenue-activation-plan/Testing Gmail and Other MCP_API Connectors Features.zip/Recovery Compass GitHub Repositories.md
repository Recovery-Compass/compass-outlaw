# Recovery Compass GitHub Repositories
**Date:** November 7, 2025  
**Total Repositories:** 6 (Eric mentioned 10+, need to verify if more exist)

---

## ACTIVE REPOSITORIES (3)

### 1. wfd-insight-hub (PRIVATE)
- **URL:** https://github.com/Recovery-Compass/wfd-insight-hub
- **Last Updated:** Nov 5, 2025 (2 days ago)
- **Status:** MOST RECENTLY ACTIVE
- **Purpose:** Unknown (need to investigate)
- **Whittier First Day Related:** YES (wfd = Whittier First Day)

### 2. five-bird (PRIVATE)
- **URL:** https://github.com/Recovery-Compass/five-bird
- **Last Updated:** Nov 3, 2025 (4 days ago)
- **Status:** ACTIVE
- **Purpose:** 5-Bird Framework implementation
- **Context:** Eric's "Environmental Response Design™" methodology

### 3. wfd-compliance (PUBLIC)
- **URL:** https://github.com/Recovery-Compass/wfd-compliance
- **Last Updated:** Nov 2, 2025 (5 days ago)
- **Status:** ACTIVE
- **Purpose:** Whittier First Day compliance work
- **Whittier First Day Related:** YES

---

## MAINTENANCE REPOSITORIES (2)

### 4. recovery-compass-main (PUBLIC)
- **URL:** https://github.com/Recovery-Compass/recovery-compass-main
- **Last Updated:** Oct 30, 2025 (8 days ago)
- **Status:** MAINTENANCE
- **Purpose:** Main Recovery Compass project documentation

### 5. clarity (PUBLIC)
- **URL:** https://github.com/Recovery-Compass/clarity
- **Last Updated:** Oct 23, 2025 (15 days ago)
- **Status:** MAINTENANCE
- **Description:** "CLARITY - Human-AI Collaboration Operating System. The world's first deadline system that distinguishes real urgency from AI-fabricated pressure."
- **Purpose:** Deadline/urgency management system (anti-AI-pressure)

---

## ARCHIVED REPOSITORIES (1)

### 6. recovery-compass-main-archived (PUBLIC)
- **URL:** https://github.com/Recovery-Compass/recovery-compass-main-archived
- **Last Updated:** Sept 26, 2025 (42 days ago)
- **Status:** ARCHIVED
- **Purpose:** Old version of recovery-compass-main

---

## MISSING REPOSITORIES

**Eric mentioned 10+ repos, but GitHub only shows 6.**

**Possible explanations:**
1. Some repos are under a different GitHub organization
2. Some repos are under Eric's personal account (not Recovery-Compass org)
3. Some repos were deleted or made private (not showing in list)
4. Eric is counting forks or branches as separate repos

**Action Required:**
- Ask Eric for complete list of all 10+ repos
- Check if any repos are under personal account (github.com/ericjones or similar)
- Verify if any repos are in other organizations

---

## PRIORITY INVESTIGATION

### Immediate (Need to Clone & Analyze):

**1. wfd-insight-hub (PRIVATE, Most Recent)**
- Last updated 2 days ago (Nov 5)
- Likely contains latest Whittier First Day work
- May have context on Donna Gallup, Randall Trice, Rudy Garcia

**2. five-bird (PRIVATE)**
- Contains 5-Bird Framework implementation
- Referenced in H Bui Law Firm evidence package
- Core methodology for Recovery Compass

**3. wfd-compliance (PUBLIC)**
- Whittier First Day compliance work
- May have MoU details, partnership history
- Could explain leadership transition

---

## NEXT STEPS

1. **Clone all 6 repos** to local sandbox
2. **Search for Whittier First Day context** (Donna Gallup, Randall Trice emails/docs)
3. **Find Devansh conversation** (May 30, 18-min transcript)
4. **Locate missing 4+ repos** (ask Eric or search personal account)
5. **Delegate to GCM** for deep analysis once repos are cloned

---

**END OF REPO INVENTORY**
