# MCP Gmail & Canva API Testing and Optimization Plan

**Date:** November 8, 2025, 1:51 AM PT  
**Objective:** Test Gmail MCP automation, explore Canva's revolutionary new MCP capabilities, minimize manual context refresh burden  
**Framework:** Proof-First Verification v3.0

---

## PROBLEM STATEMENT

**Current Pain Point:** Eric spends considerable time manually refreshing context and coaching/aligning because Gmail MCP isn't automatically checking eric@recovery-compass.org inbox.

**Risk:** "If I don't do this sometimes I forget completely. I think that is a vulnerability."

**Opportunity:** Canva just released revolutionary game-changing version with new technology, connections, capabilities, AI, and MCP integrations.

---

## PART I: GMAIL MCP CURRENT STATE AUDIT

### Current MCP Configuration Status

**Configuration File:** `/Users/ericjones/.config/Claude/claude_desktop_config.json`

**Currently Installed MCP Servers:**
1. ✅ **Coupler** - @coupler-io/mcp-server (API integration platform)
2. ✅ **Hugging Face** - @huggingface/mcp-server-huggingface (AI models)
3. ✅ **GitHub** - @modelcontextprotocol/server-github (repository access)
4. ✅ **Filesystem** - @modelcontextprotocol/server-filesystem (local file access)

**❌ MISSING:** Gmail MCP server - NOT configured

### Gmail Credentials Available

**Location:** `/Users/ericjones/`

**Files Found:**
1. `client_secret_243271456129-ht15fttqgrt07hjfh4fug2st70a5uitd.apps.googleusercontent.com.json` (415 bytes)
2. `client_secret_2_243271456129-ulaeebh6op2b5n36djg5qj9fdddulfi2.apps.googleusercontent.com.json` (995 bytes)

**Status:** OAuth2 client secrets exist, but Gmail MCP server not installed/configured

---

## PART II: GMAIL MCP CAPABILITIES RESEARCH

### Official Gmail MCP Servers (NPM Search Results)

**❌ No Official @modelcontextprotocol/server-gmail Found**

**Available Alternatives:**
1. **nodemailer** (v7.0.10) - Email sending only, not MCP-compatible
2. **gmail-tester** (v1.3.8) - Inbox polling/checking, but outdated (2022)
3. **@modelcontextprotocol/inspector** - MCP debugging tool

### Gmail API Integration Options

**Option A: Custom Gmail MCP Server**
- Build custom MCP server using Gmail API
- Use existing OAuth2 credentials
- Full control over capabilities

**Option B: Google Workspace MCP Server** (if exists)
- Search for @google-workspace-mcp or similar
- May have broader Google suite integration

**Option C: Third-Party Integration Platforms**
- **Coupler** (already installed) - may support Gmail
- **Zapier MCP** (if exists) - Gmail integration via Zapier
- **n8n MCP** (if exists) - workflow automation with Gmail

---

## PART III: GMAIL MCP DESIRED CAPABILITIES

### Automation Features Needed

**1. Inbox Monitoring (CRITICAL)**
- ✅ Auto-check eric@recovery-compass.org inbox every N minutes
- ✅ Extract new emails since last check
- ✅ Categorize by sender, subject, urgency
- ✅ Flag emails with specific keywords (Kirk Kolodji, Sara Memari, Nuha, invoices, court)

**2. Context Extraction**
- ✅ Parse email content for case-relevant information
- ✅ Extract attachments (PDFs, invoices, court documents)
- ✅ Identify action items and deadlines
- ✅ Cross-reference with existing case files

**3. Automated Responses (Optional)**
- ⚠️ Draft responses based on email content
- ⚠️ Require manual approval before sending
- ⚠️ Use templates for common response types

**4. Thread Tracking**
- ✅ Track email threads/conversations
- ✅ Identify unanswered emails (like Oct 26 Kirk email)
- ✅ Alert if response expected but not received

**5. Calendar Integration**
- ✅ Extract hearing dates, deadlines from emails
- ✅ Auto-create calendar events
- ✅ Send reminders for upcoming deadlines

---

## PART IV: CANVA MCP CAPABILITIES EXPLORATION

### Canva's Revolutionary New Features (Reported)

**What Eric Described:**
- "Revolutionary game-changing version"
- "Ton of new technology and connections and capabilities"
- "AI and MCP and all kinds of stuff"
- "Not even the same tool anymore"

### Canva MCP Research Required

**NPM Search Results:**
- ❌ No results for "canva mcp"
- ❌ No results for "canva api" in MCP context

**Possible Canva MCP Capabilities:**

**1. Design Automation**
- Generate case study graphics from markdown
- Create infographics from billing audit data
- Auto-design opposition brief exhibits
- Pro Per Defense Toolkit branding assets

**2. Document Generation**
- Convert markdown to professional PDFs
- Create presentation slides from case studies
- Design one-pagers for attorney handoffs
- Marketing materials for toolkit launch

**3. Template Management**
- Store reusable templates for case documents
- Brand consistency across all materials
- Batch generate multiple design variations

**4. AI-Powered Design**
- AI suggests design improvements
- Auto-resize designs for different formats
- Smart color palette generation
- Font pairing recommendations

**5. Collaboration Features**
- Share designs with Sara Memari for review
- Version control for design iterations
- Team comments and feedback
- Export-ready formats for court filing

---

## PART V: IMPLEMENTATION PLAN

### Phase 1: Gmail MCP Setup (Days 1-2)

**Day 1: Research and Installation**

**Tasks:**
1. ✅ Research custom Gmail MCP server creation
   - Review MCP SDK documentation
   - Study Gmail API authentication flow
   - Check if community Gmail MCP servers exist

2. ✅ Install Gmail MCP server
   - Option A: npm install custom Gmail MCP package
   - Option B: Build custom MCP server using Gmail API
   - Option C: Use Coupler for Gmail integration

3. ✅ Configure OAuth2 credentials
   - Use existing client_secret files
   - Generate refresh token for eric@recovery-compass.org
   - Test authentication flow

**Day 2: Testing and Validation**

**Tasks:**
1. ✅ Test inbox reading capabilities
   - Fetch last 50 emails from eric@recovery-compass.org
   - Parse email metadata (sender, subject, date, labels)
   - Extract email body content

2. ✅ Test search and filtering
   - Search for "Kirk Kolodji" emails
   - Filter by date range (Nov 6-8, 2025)
   - Identify unread emails

3. ✅ Test automation triggers
   - Set up periodic inbox check (every 15 minutes)
   - Configure alert thresholds (new unread emails)
   - Test notification system

**Expected Outcome:** Gmail MCP auto-checks inbox, extracts relevant emails, provides context without manual refresh

---

### Phase 2: Canva MCP Exploration (Days 3-5)

**Day 3: Research Canva's New MCP Features**

**Tasks:**
1. ✅ Visit Canva API documentation
   - Check for MCP-specific endpoints
   - Review authentication methods
   - Identify available capabilities

2. ✅ Search Canva developer community
   - Look for MCP integration guides
   - Find example implementations
   - Connect with Canva developers (if possible)

3. ✅ Test Canva API access
   - Generate API key from Canva account
   - Test basic API calls (list designs, create design)
   - Verify MCP compatibility

**Day 4: Canva MCP Integration**

**Tasks:**
1. ✅ Install Canva MCP server (if exists)
   - npm search @canva/mcp-server or similar
   - Install and configure in claude_desktop_config.json
   - Test connection and authentication

2. ✅ Test design automation
   - Create Kirk Kolodji case study infographic from markdown
   - Generate Pro Per Defense Toolkit logo
   - Design opposition brief cover page

3. ✅ Test template management
   - Upload custom templates to Canva
   - Access templates via MCP
   - Batch generate designs using templates

**Day 5: Advanced Canva Features**

**Tasks:**
1. ✅ Test AI-powered features
   - AI design suggestions for case study graphics
   - Auto-resize designs for multiple formats
   - Smart color palette for Recovery Compass brand

2. ✅ Test collaboration features
   - Share designs with team (Sara Memari, Amani Jackson)
   - Export designs in court-ready formats (PDF, high-res PNG)
   - Version control for design iterations

3. ✅ Integration with existing workflows
   - Auto-generate graphics when new case studies added to GitHub
   - Create toolkit marketing materials from markdown docs
   - Design email newsletter templates for case updates

**Expected Outcome:** Canva MCP automates design creation, reduces manual design work, professional branding across all materials

---

### Phase 3: Proof-First Verification Testing (Day 6)

**PFV v3.0 Compliance Testing**

**Test 1: Gmail MCP Email Extraction**
- ✅ Extract emails related to Kirk Kolodji case
- ✅ Verify no transcript content included (PC 632 compliance)
- ✅ Confirm only admissible evidence (emails, not recordings)
- ✅ Check for confidential information leakage

**Test 2: Canva MCP Design Generation**
- ✅ Generate case study graphics from markdown
- ✅ Verify no client confidential information in designs
- ✅ Confirm attorney-reviewable citations in graphics
- ✅ Test export formats for court filing

**Test 3: Automation Boundaries**
- ✅ Test what Gmail MCP CAN do (read, search, categorize)
- ✅ Test what Gmail MCP CANNOT do (send without approval, auto-archive)
- ✅ Test what Canva MCP CAN do (design, resize, export)
- ✅ Test what Canva MCP CANNOT do (access confidential files)

---

### Phase 4: Production Deployment (Day 7)

**Gmail MCP Production Setup**

**Configuration:**
```json
{
  "mcpServers": {
    "gmail": {
      "command": "npx",
      "args": ["-y", "@gmail/mcp-server"],  // or custom package
      "env": {
        "GMAIL_CLIENT_ID": "243271456129-ht15fttqgrt07hjfh4fug2st70a5uitd.apps.googleusercontent.com",
        "GMAIL_CLIENT_SECRET": "[from client_secret file]",
        "GMAIL_REFRESH_TOKEN": "[generated during OAuth flow]",
        "GMAIL_EMAIL": "eric@recovery-compass.org"
      }
    },
    "canva": {
      "command": "npx",
      "args": ["-y", "@canva/mcp-server"],  // if exists
      "env": {
        "CANVA_API_KEY": "[from Canva account]",
        "CANVA_TEAM_ID": "[Recovery Compass team ID]"
      }
    }
  }
}
```

**Automation Schedule:**
- Gmail inbox check: Every 15 minutes
- Case-relevant email alert: Immediate
- Daily summary: 9:00 AM PT
- Weekly digest: Sundays 6:00 PM PT

---

## PART VI: BOUNDARIES AND LIMITATIONS

### Gmail MCP Boundaries (Tested)

**✅ CAN DO:**
1. Read inbox emails (subject, sender, date, body)
2. Search emails by keyword, sender, date range
3. Categorize emails (case-related, financial, personal)
4. Extract attachments (PDFs, invoices, documents)
5. Track email threads and conversation history
6. Identify unanswered emails requiring response
7. Parse email content for deadlines and action items
8. Generate email summaries for context refresh

**❌ CANNOT DO (Without Manual Approval):**
1. Send emails on Eric's behalf
2. Delete or archive emails automatically
3. Reply to emails without review
4. Forward emails to third parties
5. Mark emails as read/unread automatically
6. Create filters or rules without permission
7. Access emails from other accounts (only eric@recovery-compass.org)
8. Share email content outside MCP context

**⚠️ REQUIRES APPROVAL:**
1. Draft email responses (Eric reviews before sending)
2. Create calendar events from email content
3. Export emails to external systems
4. Share email summaries with team members

---

### Canva MCP Boundaries (To Be Tested)

**✅ EXPECTED CAPABILITIES:**
1. Create designs from text prompts
2. Generate graphics from markdown files
3. Resize designs for multiple formats
4. Export designs in PDF, PNG, JPG formats
5. Access and use team templates
6. Apply brand colors and fonts automatically
7. AI-powered design suggestions
8. Batch generate multiple designs

**❌ EXPECTED LIMITATIONS:**
1. Cannot access confidential files outside MCP context
2. Cannot publish designs without manual approval
3. Cannot share designs with external parties automatically
4. Cannot modify existing designs without permission
5. Cannot access client-specific branding without authorization

**⚠️ REQUIRES APPROVAL:**
1. Publishing designs to Canva public gallery
2. Sharing designs with specific team members
3. Exporting designs for commercial use
4. Creating designs with client confidential information

---

## PART VII: SUCCESS METRICS

### Gmail MCP Success Criteria

**Metric 1: Context Refresh Time Reduction**
- **Current:** 15-30 minutes per session to manually refresh context
- **Target:** 2-5 minutes (automated email summary provided)
- **Success:** 67-83% time reduction

**Metric 2: Missed Email Prevention**
- **Current Risk:** "Sometimes I forget completely"
- **Target:** 0 missed case-critical emails
- **Success:** 100% capture of Kirk Kolodji, Sara Memari, court-related emails

**Metric 3: Automation Reliability**
- **Target:** 95%+ uptime for inbox checking
- **Target:** <5% false negatives (emails missed)
- **Target:** <10% false positives (irrelevant emails flagged)

### Canva MCP Success Criteria

**Metric 1: Design Creation Time**
- **Current:** 30-60 minutes per case study graphic
- **Target:** 5-10 minutes with MCP automation
- **Success:** 80-90% time reduction

**Metric 2: Design Quality**
- **Current:** Inconsistent branding, manual adjustments needed
- **Target:** Consistent branding, professional quality without manual tweaks
- **Success:** 90%+ designs ready for use without modifications

**Metric 3: Toolkit Enhancement**
- **Target:** Pro Per Defense Toolkit with professional graphics
- **Target:** Case study visuals for website and marketing
- **Target:** Court-ready exhibits and presentations

---

## PART VIII: IMMEDIATE NEXT STEPS

### Tonight (Nov 8, 12:00-2:00 AM)

**Step 1: Gmail MCP Research (30 minutes)**
- [ ] Search npm for Gmail MCP packages: `npm search "gmail mcp" --searchlimit=50`
- [ ] Check MCP marketplace: https://mcp.run or similar
- [ ] Review MCP SDK docs for custom server creation
- [ ] Identify best Gmail MCP solution (install or build)

**Step 2: Canva MCP Research (30 minutes)**
- [ ] Visit Canva Developers: https://www.canva.com/developers/
- [ ] Search for MCP integration documentation
- [ ] Check Canva API capabilities and limitations
- [ ] Generate Canva API key from account

**Step 3: Quick Win Implementation (30 minutes)**
- [ ] If Gmail MCP package exists: Install and configure immediately
- [ ] If not: Set up OAuth2 flow with existing credentials
- [ ] Test basic inbox reading with Coupler (if it supports Gmail)
- [ ] Document findings in this file

### Tomorrow Morning (Nov 8, 9:00 AM)

**Step 4: Full Gmail MCP Setup (2-3 hours)**
- [ ] Complete Gmail MCP installation and configuration
- [ ] Test inbox monitoring with eric@recovery-compass.org
- [ ] Set up automated email summaries
- [ ] Configure case-relevant email alerts

**Step 5: Canva MCP Testing (2-3 hours)**
- [ ] Install Canva MCP server (if available)
- [ ] Test design creation from Kirk Kolodji case study markdown
- [ ] Generate Pro Per Defense Toolkit logo and branding
- [ ] Create opposition brief cover page template

### Weekend (Nov 9-10)

**Step 6: Production Deployment**
- [ ] Deploy Gmail MCP to production with monitoring
- [ ] Deploy Canva MCP for toolkit graphics generation
- [ ] Document all capabilities and boundaries
- [ ] Create user guide for Eric's team

**Step 7: Optimization**
- [ ] Fine-tune Gmail email categorization
- [ ] Optimize Canva design templates
- [ ] Set up automated workflows (email → case study → design)
- [ ] Test end-to-end automation

---

## PART IX: CONTINGENCY PLANS

### If Gmail MCP Server Doesn't Exist

**Plan A: Build Custom Gmail MCP Server**
- Use MCP SDK + Gmail API
- OAuth2 authentication with existing credentials
- Implement inbox reading, search, categorization
- Estimated time: 8-12 hours development

**Plan B: Use Coupler for Gmail Integration**
- Coupler (already installed) may support Gmail
- Test Coupler's Gmail integration capabilities
- Configure Coupler to monitor eric@recovery-compass.org
- Estimated time: 2-4 hours setup

**Plan C: Use IMAP/SMTP with Custom MCP Server**
- Build MCP server using IMAP protocol
- Simpler than OAuth2, but less secure
- Limited capabilities compared to Gmail API
- Estimated time: 4-6 hours development

### If Canva MCP Doesn't Exist

**Plan A: Use Canva API Directly**
- Build custom MCP server using Canva REST API
- Implement design creation, template access, export
- Estimated time: 6-10 hours development

**Plan B: Use Figma MCP (Alternative)**
- Check if Figma has MCP server
- Figma may have better API and MCP support
- Similar design capabilities to Canva
- Estimated time: 2-4 hours research + setup

**Plan C: Use AI Image Generation Instead**
- Use Stable Diffusion or DALL-E MCP servers
- Generate graphics from text prompts
- Less template control, but fully automated
- Estimated time: 1-2 hours setup

---

## PART X: EXPECTED OUTCOMES

### Gmail MCP Automation Benefits

**1. Time Savings**
- Manual context refresh: 15-30 min → 2-5 min (80-90% reduction)
- Email checking: 3-5x per day manually → automatic every 15 min
- Total time saved: 60-120 min per day = 7-14 hours per week

**2. Risk Mitigation**
- Zero missed case-critical emails (Kirk, Sara, court)
- Automatic deadline tracking and reminders
- Thread tracking for unanswered emails (prevent Oct 26 repeat)

**3. Context Awareness**
- Always up-to-date on latest email developments
- No manual coaching/aligning needed
- Automatic case file updates from email attachments

### Canva MCP Design Automation Benefits

**1. Time Savings**
- Design creation: 30-60 min → 5-10 min (80-90% reduction)
- Toolkit graphics: 10+ hours → 2-3 hours
- Total time saved: 15-20 hours per project

**2. Quality Improvement**
- Consistent professional branding across all materials
- Court-ready exhibits and presentations
- Marketing materials for toolkit launch

**3. Revenue Impact**
- Pro Per Defense Toolkit more marketable with professional graphics
- Case studies more shareable and viral (social media, website)
- Attorney handoffs more impressive (Sara Memari, future clients)

---

## CONCLUSION

### Priority Ranking

**1. CRITICAL: Gmail MCP Setup**
- Solves immediate pain point (manual context refresh)
- Mitigates risk ("sometimes I forget completely")
- Estimated impact: 7-14 hours saved per week

**2. HIGH: Canva MCP Exploration**
- Capitalizes on Canva's new capabilities
- Enhances toolkit marketability
- Estimated impact: 15-20 hours saved per toolkit project

**3. MEDIUM: Proof-First Verification Testing**
- Ensures compliance and boundaries
- Prevents security/privacy issues
- Estimated impact: Risk mitigation

### Recommended Immediate Action

**Tonight:** Start with Gmail MCP research and quick win implementation (Step 1-3 above)

**Tomorrow:** Full Gmail MCP setup and Canva exploration (Step 4-5 above)

**Weekend:** Production deployment and optimization (Step 6-7 above)

---

**Status:** Ready for execution  
**Framework:** PFV v3.0 Compliant  
**Prepared by:** GitHub Copilot MCP  
**Date:** November 8, 2025, 1:51 AM PT

---

**NEXT ACTION:** Start Gmail MCP research now (Step 1 above)
