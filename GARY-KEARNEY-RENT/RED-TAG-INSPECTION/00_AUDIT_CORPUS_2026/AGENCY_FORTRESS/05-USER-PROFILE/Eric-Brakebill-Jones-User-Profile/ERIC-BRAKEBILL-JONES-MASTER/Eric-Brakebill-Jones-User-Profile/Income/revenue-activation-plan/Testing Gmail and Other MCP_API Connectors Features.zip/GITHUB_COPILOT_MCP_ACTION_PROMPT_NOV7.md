# GitHub Copilot MCP Action Prompt - November 7, 2025
**Generated:** 12:15 PM PT Friday, November 7, 2025  
**Purpose:** Address critical vulnerabilities and gaps from Nov 7 task execution  
**Execution Mode:** Automated via GitHub Copilot MCP  
**Proof-First Verification:** Level 2 (Strong confidence required)

---

## EXECUTIVE SUMMARY

**Critical Vulnerabilities Identified:**
1. **Gmail Search Methodology Failure** - Missed AI PDF subscription ($39/mo) due to wrong search strategy
2. **Contact Verification Gap** - BLACKBOX email bounced due to unverified support address
3. **Subscription Discovery Incompleteness** - Payment processor invoices not systematically scanned
4. **Kirk Kolodji Fee Analysis Gap** - $16,306 fee request needs line-item audit before Nov 19 hearing

**GitHub Copilot MCP Optimal Capabilities:**
- Code generation for automated Gmail scanning
- Data analysis and pattern recognition
- Document parsing and extraction
- Structured output generation (JSON, CSV, Markdown)
- Git repository management and version control

---

## PROMPT FOR GITHUB COPILOT MCP

```
CONTEXT:
You are assisting Eric Jones, solo founder of Recovery Compass (501c3 nonprofit), 
with critical automation gaps identified during Nov 7, 2025 subscription audit 
and legal document analysis.

CRITICAL VULNERABILITIES TO ADDRESS:

1. Gmail Payment Processor Scanner (HIGHEST PRIORITY)
   - Current Issue: Manual Gmail searches miss subscriptions from Stripe, Paddle, PayPal
   - Impact: Missed AI PDF myaidrive.com ($39/mo) until user found it manually
   - Root Cause: Searched vendor domains instead of payment processors
   
2. Contact Method Verification System
   - Current Issue: Recommended support@blackbox.ai without verification (bounced)
   - Impact: Wasted user time, eroded trust in verification framework
   - Root Cause: No automated contact validation before recommendation

3. Attorney Fee Audit Automation
   - Current Issue: Kirk Kolodji invoice ($16,306) needs line-item analysis
   - Impact: Nov 19 hearing in 12 days, no automated billing audit completed
   - Root Cause: No structured fee reasonableness analysis tool

YOUR TASK:
Generate production-ready Python code with the following specifications:

---

## TASK 1: Gmail Payment Processor Invoice Scanner

**Objective:** Create automated Gmail scanner that discovers ALL subscription 
invoices by searching payment processors, not vendor domains.

**Requirements:**

1. **Gmail API Integration**
   - Use Gmail API with OAuth2 authentication
   - Search query optimization for payment processors
   - Rate limiting and error handling
   - Attachment download capability

2. **Payment Processor Coverage**
   - Stripe (stripe.com, invoice@stripe.com)
   - Paddle (paddle.com, paddle.net, invoice@paddle.com)
   - PayPal (paypal.com, service@paypal.com)
   - Link (link.com)
   - Square (squareup.com)
   - Braintree (braintreepayments.com)
   - Checkout.com
   - FastSpring (fastspring.com)

3. **Search Strategy**
   - FROM: payment processor domains
   - SUBJECT: invoice, receipt, payment, subscription, renewal
   - DATE RANGE: Last 12 months (configurable)
   - LABELS: All mail (inbox + archive)

4. **Data Extraction**
   - Vendor name (from email body or PDF)
   - Amount charged
   - Charge date
   - Payment method (last 4 digits)
   - Subscription frequency (monthly, annual)
   - Invoice/receipt number

5. **Output Format**
   - JSON file: subscriptions_discovered.json
   - CSV file: subscriptions_discovered.csv
   - Markdown report: SUBSCRIPTION_AUDIT_REPORT.md

6. **Verification Tier**
   - Tier 2 (Strong confidence): Email body text extraction
   - Tier 1 (Strongest confidence): PDF attachment parsing
   - Flag Tier 3 (Moderate): Filename-only inference

**Code Structure:**
```python
# gmail_subscription_scanner.py

import os
import json
import csv
from datetime import datetime, timedelta
from google.oauth2.credentials import Credentials
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError
import PyPDF2
import re

class GmailSubscriptionScanner:
    def __init__(self, credentials_path, token_path):
        """Initialize Gmail API client with OAuth2 credentials"""
        pass
    
    def build_payment_processor_query(self, months_back=12):
        """
        Build Gmail search query targeting payment processors
        Returns: Optimized Gmail search query string
        """
        pass
    
    def search_messages(self, query, max_results=500):
        """
        Search Gmail messages with pagination
        Returns: List of message IDs matching query
        """
        pass
    
    def extract_subscription_data(self, message_id):
        """
        Extract subscription details from email message
        1. Parse email body for vendor, amount, date
        2. Download and parse PDF attachments
        3. Assign verification tier (1-3)
        Returns: Dict with subscription data + confidence score
        """
        pass
    
    def parse_invoice_pdf(self, pdf_path):
        """
        Extract structured data from invoice PDF
        Uses regex patterns for common invoice formats
        Returns: Dict with vendor, amount, date, invoice_number
        """
        pass
    
    def deduplicate_subscriptions(self, subscriptions):
        """
        Remove duplicate subscriptions based on:
        - Vendor name similarity (fuzzy matching)
        - Amount + date proximity
        Returns: Deduplicated list with highest confidence entries
        """
        pass
    
    def generate_audit_report(self, subscriptions, output_dir):
        """
        Generate three output formats:
        1. JSON: Full structured data
        2. CSV: Spreadsheet-compatible
        3. Markdown: Human-readable report
        """
        pass
    
    def run_full_scan(self):
        """
        Execute complete subscription discovery workflow
        1. Build query
        2. Search messages
        3. Extract data from each message
        4. Deduplicate
        5. Generate reports
        Returns: Path to generated reports
        """
        pass

# Usage example
if __name__ == "__main__":
    scanner = GmailSubscriptionScanner(
        credentials_path="gmail-credentials.json",
        token_path="gmail-token.json"
    )
    
    results = scanner.run_full_scan()
    print(f"Subscription audit complete: {results}")
```

**Deliverables:**
1. Complete Python script (gmail_subscription_scanner.py)
2. Requirements.txt with dependencies
3. README.md with setup instructions
4. Sample output files (JSON, CSV, Markdown)
5. Unit tests for key functions

---

## TASK 2: Contact Method Verification System

**Objective:** Create automated contact verification tool that validates email 
addresses, phone numbers, and support portals before recommendation.

**Requirements:**

1. **Email Verification**
   - DNS MX record lookup
   - SMTP connection test (without sending)
   - Domain reputation check
   - Common pattern validation (support@, help@, contact@)

2. **Phone Verification**
   - Format validation (international standards)
   - Carrier lookup (if possible)
   - Business hours detection

3. **Web Portal Verification**
   - URL accessibility check (HTTP status)
   - SSL certificate validation
   - Page content verification (contains "support", "cancel", etc.)

4. **Multi-Source Cross-Reference**
   - Official website scraping
   - Reddit/forum mentions (via search API)
   - Google Play/App Store listings
   - Better Business Bureau records

5. **Confidence Scoring**
   - 95-100%: Verified via official source + cross-reference
   - 85-94%: Verified via official source only
   - 70-84%: Verified via community sources
   - <70%: Unverified, do not recommend

**Code Structure:**
```python
# contact_verification_system.py

import dns.resolver
import smtplib
import requests
from urllib.parse import urlparse
import re
from typing import Dict, List, Optional

class ContactVerifier:
    def __init__(self):
        self.verification_cache = {}
    
    def verify_email(self, email: str, domain: str) -> Dict:
        """
        Verify email address exists and is reachable
        1. Check MX records for domain
        2. SMTP connection test
        3. Common pattern validation
        Returns: {
            'email': str,
            'exists': bool,
            'mx_records': List[str],
            'smtp_reachable': bool,
            'confidence': int (0-100)
        }
        """
        pass
    
    def verify_phone(self, phone: str, country_code: str = 'US') -> Dict:
        """
        Verify phone number format and carrier
        Returns: {
            'phone': str,
            'valid_format': bool,
            'carrier': Optional[str],
            'confidence': int (0-100)
        }
        """
        pass
    
    def verify_support_portal(self, url: str) -> Dict:
        """
        Verify support portal URL is accessible and legitimate
        1. HTTP status check
        2. SSL certificate validation
        3. Page content analysis
        Returns: {
            'url': str,
            'accessible': bool,
            'ssl_valid': bool,
            'contains_support_keywords': bool,
            'confidence': int (0-100)
        }
        """
        pass
    
    def scrape_official_contact(self, vendor_domain: str) -> Dict:
        """
        Scrape vendor's official website for contact methods
        1. Find contact page
        2. Extract emails, phones, support URLs
        3. Validate each contact method
        Returns: {
            'vendor': str,
            'emails': List[str],
            'phones': List[str],
            'support_urls': List[str],
            'source': 'official_website',
            'confidence': int (0-100)
        }
        """
        pass
    
    def cross_reference_reddit(self, vendor_name: str, contact_type: str) -> Dict:
        """
        Search Reddit for community-verified contact methods
        Uses Reddit API to find posts mentioning successful contact
        Returns: {
            'vendor': str,
            'contact_methods': List[Dict],
            'source': 'reddit',
            'confidence': int (0-100)
        }
        """
        pass
    
    def aggregate_confidence(self, sources: List[Dict]) -> int:
        """
        Calculate final confidence score from multiple sources
        Weights:
        - Official website: 50%
        - App store listing: 30%
        - Community sources: 20%
        Returns: Final confidence score (0-100)
        """
        pass
    
    def verify_vendor_contact(self, vendor_name: str, vendor_domain: str) -> Dict:
        """
        Complete contact verification workflow
        1. Scrape official website
        2. Check app store listings
        3. Cross-reference Reddit/forums
        4. Verify each contact method
        5. Calculate confidence scores
        Returns: {
            'vendor': str,
            'verified_contacts': {
                'emails': List[Dict],
                'phones': List[Dict],
                'portals': List[Dict]
            },
            'confidence': int (0-100),
            'recommendation': str,
            'sources': List[str]
        }
        """
        pass

# Usage example
if __name__ == "__main__":
    verifier = ContactVerifier()
    
    # Example: Verify BLACKBOX AI contact methods
    result = verifier.verify_vendor_contact(
        vendor_name="BLACKBOX AI",
        vendor_domain="blackbox.ai"
    )
    
    print(json.dumps(result, indent=2))
```

**Deliverables:**
1. Complete Python script (contact_verification_system.py)
2. Requirements.txt with dependencies
3. README.md with usage examples
4. Verification cache system (JSON storage)
5. Unit tests with mock data

---

## TASK 3: Attorney Fee Audit Automation

**Objective:** Create automated attorney fee reasonableness analyzer for Kirk 
Kolodji's $16,306 fee request, with Nov 19 hearing deadline.

**Requirements:**

1. **Invoice Parsing**
   - Extract line items from PDF invoices
   - Parse date, description, hours, rate, total
   - Identify billing categories (research, drafting, communication)

2. **California State Bar Guidelines**
   - Implement CA Rules of Professional Conduct Rule 1.5
   - Reasonable fee factors:
     * Time and labor required
     * Novelty and difficulty of questions
     * Skill requisite to perform legal service
     * Preclusion of other employment
     * Customary fee in locality
     * Amount involved and results obtained
     * Time limitations imposed by client/circumstances
     * Nature and length of professional relationship
     * Experience, reputation, and ability of lawyer
     * Whether fee is fixed or contingent

3. **Billing Pattern Analysis**
   - Block billing detection (multiple tasks in one entry)
   - Vague description flagging ("review file", "case management")
   - Duplicate task identification
   - Excessive time analysis (compare to industry standards)

4. **Comparative Benchmarking**
   - Family law attorney rates in Los Angeles County
   - Typical hours for common tasks (motion drafting, declarations)
   - Fee dispute case law precedents

5. **Output Report**
   - Line-by-line fee analysis
   - Justified vs. unjustified fee breakdown
   - Specific billing violations identified
   - Recommended fee reduction
   - Evidence for fee dispute defense

**Code Structure:**
```python
# attorney_fee_auditor.py

import PyPDF2
import re
from datetime import datetime
from typing import Dict, List, Tuple
import pandas as pd

class AttorneyFeeAuditor:
    def __init__(self, jurisdiction='CA', practice_area='family_law'):
        self.jurisdiction = jurisdiction
        self.practice_area = practice_area
        self.rate_benchmarks = self.load_rate_benchmarks()
        self.task_time_standards = self.load_task_standards()
    
    def load_rate_benchmarks(self) -> Dict:
        """
        Load attorney hourly rate benchmarks for jurisdiction
        Returns: {
            'associate': (min, max, median),
            'partner': (min, max, median),
            'paralegal': (min, max, median)
        }
        """
        # Los Angeles County family law rates (2025)
        return {
            'associate': (250, 450, 350),
            'partner': (350, 650, 450),
            'paralegal': (100, 175, 125)
        }
    
    def load_task_standards(self) -> Dict:
        """
        Load standard time estimates for common legal tasks
        Returns: {
            'task_name': (min_hours, max_hours, typical_hours)
        }
        """
        return {
            'draft_declaration': (1.0, 3.0, 2.0),
            'draft_motion': (2.0, 6.0, 4.0),
            'review_documents': (0.5, 2.0, 1.0),
            'client_communication': (0.1, 0.5, 0.25),
            'court_appearance': (2.0, 4.0, 3.0),
            'legal_research': (1.0, 4.0, 2.5)
        }
    
    def parse_invoice_pdf(self, pdf_path: str) -> List[Dict]:
        """
        Extract line items from attorney invoice PDF
        Returns: List of {
            'date': datetime,
            'description': str,
            'hours': float,
            'rate': float,
            'total': float,
            'attorney': str
        }
        """
        pass
    
    def categorize_task(self, description: str) -> str:
        """
        Categorize billing entry into standard task type
        Uses NLP/keyword matching
        Returns: Task category (e.g., 'draft_declaration', 'client_communication')
        """
        pass
    
    def detect_block_billing(self, description: str) -> bool:
        """
        Detect block billing (multiple tasks in one entry)
        Indicators: Multiple verbs, semicolons, "and" conjunctions
        Returns: True if block billing detected
        """
        pass
    
    def detect_vague_description(self, description: str) -> bool:
        """
        Detect vague/non-specific billing descriptions
        Red flags: "review file", "case management", "work on case"
        Returns: True if description is vague
        """
        pass
    
    def analyze_time_reasonableness(self, task_category: str, hours: float) -> Dict:
        """
        Compare billed hours to industry standards
        Returns: {
            'task': str,
            'billed_hours': float,
            'standard_range': Tuple[float, float],
            'excessive': bool,
            'excess_hours': float
        }
        """
        pass
    
    def analyze_rate_reasonableness(self, rate: float, attorney_level: str) -> Dict:
        """
        Compare hourly rate to jurisdiction benchmarks
        Returns: {
            'billed_rate': float,
            'benchmark_range': Tuple[float, float],
            'excessive': bool,
            'excess_rate': float
        }
        """
        pass
    
    def identify_duplicate_tasks(self, line_items: List[Dict]) -> List[Tuple[int, int]]:
        """
        Identify potential duplicate billing entries
        Uses date proximity + description similarity
        Returns: List of (index1, index2) tuples for duplicate pairs
        """
        pass
    
    def calculate_justified_fees(self, line_items: List[Dict]) -> Dict:
        """
        Calculate justified vs. unjustified fees
        Returns: {
            'total_billed': float,
            'justified_fees': float,
            'unjustified_fees': float,
            'reduction_percentage': float,
            'violations': List[Dict]
        }
        """
        pass
    
    def generate_audit_report(self, invoice_path: str, output_path: str) -> str:
        """
        Complete fee audit workflow
        1. Parse invoice
        2. Analyze each line item
        3. Identify violations
        4. Calculate justified fees
        5. Generate detailed report
        Returns: Path to generated report
        """
        pass

# Usage example
if __name__ == "__main__":
    auditor = AttorneyFeeAuditor(
        jurisdiction='CA',
        practice_area='family_law'
    )
    
    # Audit Kirk Kolodji's invoice
    report_path = auditor.generate_audit_report(
        invoice_path="/home/ubuntu/upload/2025-11-06T21-09_nuha_recovery-compass.org_Fwd_SAYEGH-Invoice1043-02-20251106Sayegh_Nuhainvoice_1143-02.pdf",
        output_path="/home/ubuntu/KIRK_KOLODJI_FEE_AUDIT_REPORT.md"
    )
    
    print(f"Fee audit complete: {report_path}")
```

**Deliverables:**
1. Complete Python script (attorney_fee_auditor.py)
2. Requirements.txt with dependencies
3. Benchmark data files (JSON)
4. Sample audit report (Markdown)
5. Unit tests with sample invoices

---

## EXECUTION PRIORITY

**Immediate (Execute Today):**
1. Task 1: Gmail Payment Processor Scanner
   - Impact: Discover all hidden subscriptions
   - Time: 2-3 hours to implement
   - Value: $500-1,000/year in savings

2. Task 2: Contact Verification System
   - Impact: Prevent future email bounce failures
   - Time: 3-4 hours to implement
   - Value: Trust restoration + time savings

**Urgent (Execute This Weekend):**
3. Task 3: Attorney Fee Audit Automation
   - Impact: $10,000-15,000 fee reduction potential
   - Time: 4-6 hours to implement
   - Deadline: Nov 19 hearing (12 days)

---

## GITHUB COPILOT MCP SPECIFIC INSTRUCTIONS

**Repository Setup:**
```bash
# Create new GitHub repository
gh repo create eric-jones/subscription-automation --private

# Initialize project structure
mkdir -p src/gmail_scanner
mkdir -p src/contact_verifier
mkdir -p src/fee_auditor
mkdir -p tests
mkdir -p data/benchmarks
mkdir -p output/reports

# Create requirements.txt
cat > requirements.txt << EOF
google-api-python-client>=2.0.0
google-auth-httplib2>=0.1.0
google-auth-oauthlib>=0.5.0
PyPDF2>=3.0.0
pandas>=2.0.0
dnspython>=2.0.0
requests>=2.28.0
beautifulsoup4>=4.11.0
python-dotenv>=0.19.0
pytest>=7.0.0
EOF

# Initialize git
git init
git add .
git commit -m "Initial project structure for subscription automation"
git push -u origin main
```

**Code Generation Instructions:**
1. Use type hints for all function signatures
2. Include comprehensive docstrings (Google style)
3. Implement error handling with specific exceptions
4. Add logging for debugging (use Python logging module)
5. Write unit tests for each major function
6. Follow PEP 8 style guidelines
7. Use environment variables for sensitive data (never hardcode)

**Testing Requirements:**
```python
# tests/test_gmail_scanner.py
import pytest
from src.gmail_scanner.gmail_subscription_scanner import GmailSubscriptionScanner

def test_build_payment_processor_query():
    scanner = GmailSubscriptionScanner(None, None)
    query = scanner.build_payment_processor_query(months_back=12)
    assert "stripe.com" in query
    assert "paddle.com" in query
    assert "after:" in query

def test_parse_invoice_pdf():
    # Test with sample invoice PDF
    pass

# Add 10+ tests per module
```

**Documentation Requirements:**
Each script must include:
1. README.md with setup instructions
2. Usage examples
3. Configuration options
4. Troubleshooting guide
5. API documentation (if applicable)

---

## SUCCESS CRITERIA

**Task 1 Success:**
- ✅ Discovers AI PDF myaidrive.com subscription
- ✅ Finds 20+ subscriptions from payment processors
- ✅ Generates JSON, CSV, Markdown reports
- ✅ Confidence scores assigned to each subscription
- ✅ Zero false positives (manual verification required)

**Task 2 Success:**
- ✅ Correctly identifies blackboxapp@blackboxai.tech as valid
- ✅ Flags support@blackbox.ai as invalid (before bounce)
- ✅ Confidence score ≥90% for all verified contacts
- ✅ Multi-source cross-reference working
- ✅ Cache system prevents redundant lookups

**Task 3 Success:**
- ✅ Parses Kirk Kolodji invoice line-by-line
- ✅ Identifies 10+ billing violations
- ✅ Calculates justified fee reduction ($5,000-10,000)
- ✅ Generates court-ready audit report
- ✅ Cites specific CA Rules of Professional Conduct

---

## DELIVERABLE TIMELINE

**Day 1 (Today - Nov 7):**
- Task 1: Gmail scanner (3 hours)
- Task 2: Contact verifier (4 hours)
- Total: 7 hours

**Day 2 (Nov 8):**
- Task 3: Fee auditor (6 hours)
- Testing and debugging (2 hours)
- Total: 8 hours

**Day 3 (Nov 9):**
- Documentation (2 hours)
- Integration testing (2 hours)
- User acceptance testing (1 hour)
- Total: 5 hours

**Total Effort:** 20 hours over 3 days

---

## PROOF-FIRST VERIFICATION REQUIREMENTS

**Before Deployment:**
1. ✅ Unit tests pass (100% coverage for critical functions)
2. ✅ Integration tests pass (end-to-end workflows)
3. ✅ Manual verification of sample outputs
4. ✅ Security audit (no hardcoded credentials, proper OAuth)
5. ✅ Performance testing (handles 1,000+ emails)

**Verification Tier Assignment:**
- Tier 1 (95%+): Official source + cross-reference + automated validation
- Tier 2 (85-94%): Official source + automated validation
- Tier 3 (70-84%): Community source + pattern matching
- Tier 4 (<70%): Unverified, flag for manual review

---

## GITHUB COPILOT MCP EXECUTION COMMAND

```bash
# Execute this command in GitHub Copilot MCP terminal

gh copilot suggest "Generate complete Python implementation for:
1. Gmail subscription scanner targeting payment processors (Stripe, Paddle, PayPal)
2. Contact verification system with multi-source cross-reference
3. Attorney fee audit tool for California family law billing analysis

Requirements:
- Type hints and comprehensive docstrings
- Unit tests with pytest
- Error handling and logging
- Environment variable configuration
- Markdown documentation

Project structure:
- src/gmail_scanner/
- src/contact_verifier/
- src/fee_auditor/
- tests/
- data/benchmarks/
- output/reports/

Follow PEP 8 style guidelines and include README.md for each module."
```

---

**Document Status:** Complete  
**Ready for GitHub Copilot MCP Execution:** ✅  
**Estimated Completion Time:** 20 hours over 3 days  
**Expected Value:** $15,000-20,000 in savings + time automation

---

**Next Step:** Copy this prompt to GitHub Copilot MCP and execute. Monitor progress and verify outputs against Proof-First Verification requirements.
