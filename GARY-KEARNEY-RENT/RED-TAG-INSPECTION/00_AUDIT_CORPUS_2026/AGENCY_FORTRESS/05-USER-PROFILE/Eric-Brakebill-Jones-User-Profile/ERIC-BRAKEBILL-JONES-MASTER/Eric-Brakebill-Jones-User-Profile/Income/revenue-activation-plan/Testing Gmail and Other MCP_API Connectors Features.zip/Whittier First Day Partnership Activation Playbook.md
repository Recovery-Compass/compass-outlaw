# Whittier First Day Partnership Activation Playbook
**Date:** November 7, 2025  
**Partnership:** Recovery Compass + Whittier First Day  
**Status:** Leadership transition (Dr. Donna Gallup → Randall Trice), MoU signed Aug 27, 2025

---

## SITUATION ANALYSIS

### Original Partnership:
- **MoU Signed:** Aug 27, 2025 (Dr. Donna Gallup, Former CEO)
- **Original Champion:** Dr. Donna Gallup (pushed out, no longer at organization)
- **Current Leadership:** Randall Trice (New CEO/Executive Director, taking time off)
- **Current Contact:** Rudy Garcia (Acting Chief Program Officer, covering for Randall)

### Recent Communication:
- **Nov 6, 4:00 PM:** Rudy reached out on behalf of Randall (who's taking time off)
- **Nov 6, 5:19 PM:** Eric offered to meet with someone else in the meantime
- **Nov 6, 11:58 PM:** Rudy said "I'll send options upon his return" (not "let's meet now")

### Problem:
- Original champion (Donna) gone
- New CEO (Randall) not engaged yet (taking time off)
- Acting CPO (Rudy) is polite but not enthusiastic
- Eric is in passive position (waiting for them to reach out)

---

## PROVEN FRAMEWORK (From Top 2% Nonprofit Consultants)

### 1. MoU → PAID PILOT CONVERSION PLAYBOOK

**Step 1: Establish Mutual Value Early**
- ✅ **DONE:** MoU signed Aug 27, 2025 (documented partnership intent)
- ⚠️ **MISSING:** Measurable outcomes that pilot will address (organizational ROI)

**Action:** Create 1-page "MoU Value Summary" showing:
- What Whittier gets: Compliance system, data insights, program optimization
- What Recovery Compass gets: Pilot data, case studies, revenue
- Measurable outcomes: X% reduction in compliance time, Y% increase in program effectiveness

**Step 2: Develop SOW (Scope of Work)**
- ❌ **MISSING:** Detailed proposal with deliverables, timelines, success metrics

**Action:** Create "Whittier First Day Pilot SOW" with:
- **Deliverables:** Compliance dashboard, weekly reports, quarterly analysis
- **Timeline:** 90-day pilot (Jan-Mar 2026)
- **Success Metrics:** Compliance time reduced by 30%, data quality improved by 50%
- **Payment Terms:** $5K-10K (project-based or $2K/month retainer)

**Step 3: Build Opt-Out Clauses to Reduce Risk**
- ❌ **MISSING:** Low-risk engagement offer (30-60 day opt-out)

**Action:** Add to SOW:
- "30-day opt-out clause: If Whittier is not satisfied with pilot progress, cancel with no penalty"
- "Milestone-based payments: Pay only after each deliverable is approved"

**Step 4: Pilot Start Authorization**
- ⚠️ **AT RISK:** Randall Trice (decision-maker) not engaged, Rudy Garcia (Acting CPO) not authorized

**Action:** 
- **Option A:** Wait for Randall to return, present SOW directly
- **Option B:** Present SOW to Rudy, ask him to champion to Randall
- **Option C:** Request meeting with Whittier board/staff to build coalition

**Step 5: Deliver Value Rapidly**
- ❌ **MISSING:** Visible impact or learning within first weeks

**Action:** Offer "Quick Win" to demonstrate value:
- "Free 1-week compliance audit: I'll analyze your current system and show 3 immediate improvements"
- "No cost, no obligation, just demonstrating what the pilot can do"

**Step 6: Formalize with Simple Contract**
- ❌ **MISSING:** Standardized pilot agreement

**Action:** Create "Whittier First Day Pilot Agreement" (1-2 pages):
- Payment terms: $5K-10K (project-based or $2K/month x 3 months)
- Milestones: Month 1 (dashboard), Month 2 (reports), Month 3 (analysis)
- Review points: Monthly check-ins with Randall/Rudy
- Opt-out: 30-day cancellation clause

---

### 2. PARTNERSHIP ACTIVATION STRATEGIES (LEADERSHIP CHANGE)

**When nonprofit leadership changes (Donna → Randall):**

**Step 1: Map New Stakeholders**
- ✅ **DONE:** Identified Randall Trice (New CEO), Rudy Garcia (Acting CPO)
- ⚠️ **MISSING:** Board members, program staff, other decision-makers

**Action:** Ask Rudy: "Who else should I connect with while Randall is out? Happy to brief program staff or board members on the MoU."

**Step 2: Re-Onboard the New Leader**
- ❌ **NOT DONE:** Randall hasn't been briefed on partnership goals, pilot outcomes, prior enthusiasm

**Action:** Create "Whittier First Day Partnership Brief" (1-page) for Randall:
- **Background:** MoU signed Aug 27 with Dr. Gallup
- **Goals:** Compliance optimization, data insights, program effectiveness
- **Status:** Ready to launch pilot, waiting for Randall's approval
- **Next Steps:** 30-min call to discuss pilot SOW

**Step 3: Show Early Wins**
- ❌ **MISSING:** Fast, tangible results from preliminary work

**Action:** Offer "Free Compliance Audit" (1-week, no cost):
- Analyze current compliance system
- Identify 3 immediate improvements
- Demonstrate value before asking for paid pilot

**Step 4: Leverage Formal Documentation**
- ✅ **DONE:** MoU signed Aug 27, 2025 (organizational commitment, not personal)

**Action:** In all communication, reference MoU:
- "Per our Aug 27 MoU with Dr. Gallup, Recovery Compass is ready to launch the pilot phase"
- "This is an organizational commitment, not dependent on any single leader"

**Step 5: Reassess Strategic Fit**
- ⚠️ **UNKNOWN:** Randall's priorities may differ from Donna's

**Action:** In first call with Randall, ask:
- "What are your top 3 priorities for Whittier First Day in 2026?"
- "How can Recovery Compass support those priorities?"
- Adapt pilot framing to match his agenda

**Step 6: Build Board or Staff Coalitions**
- ❌ **MISSING:** Broader support across departments or board

**Action:** Request introductions:
- "Rudy, can you introduce me to 2-3 program staff who would benefit from the compliance system?"
- "I'd love to brief them on how it works and get their input"

---

### 3. PILOT PRICING MODELS FOR NONPROFITS

| Model | Features | When to Use | Whittier Fit |
|-------|----------|-------------|--------------|
| **Hourly** | Bill for each hour of service | Open-ended pilots, advisory work | ❌ Too vague, hard to budget |
| **Project-based** | Fixed fee for defined deliverables | Well-scoped pilots with clear start/end | ✅ **RECOMMENDED:** $5K-10K for 90-day pilot |
| **Retainer** | Recurring monthly/quarterly fee | Ongoing support/guidance needed | ✅ **ALTERNATIVE:** $2K/month x 3 months = $6K |

**RECOMMENDATION: Project-Based ($7.5K for 90-day pilot)**

**Why:**
- Clear deliverables (dashboard, reports, analysis)
- Fixed budget (easier for nonprofit to approve)
- Milestone-based payments (reduces risk)
- 30-day opt-out clause (builds trust)

**Payment Structure:**
- **Month 1:** $2.5K (deliver compliance dashboard)
- **Month 2:** $2.5K (deliver weekly reports)
- **Month 3:** $2.5K (deliver quarterly analysis)
- **Total:** $7.5K (paid incrementally, not upfront)

---

### 4. POSITIONING VALUE (ORIGINAL CHAMPION REPLACED)

**When CEO (Donna) is replaced by Randall:**

**Strategy 1: Frame as Organizationally Strategic**
- ❌ **CURRENT:** Partnership seen as "Donna's project"
- ✅ **TARGET:** Partnership seen as "Whittier's strategic initiative"

**Action:** In all communication, emphasize:
- "This MoU was signed by Whittier First Day (the organization), not just Dr. Gallup"
- "The board/staff approved this partnership as part of Whittier's 2025-2026 strategic plan"
- "Randall inherits a ready-to-launch pilot, not a new proposal"

**Strategy 2: Leverage Documentation and Commitments**
- ✅ **DONE:** MoU signed Aug 27, 2025

**Action:** Attach MoU to every email/proposal:
- "Per our signed MoU (attached), Recovery Compass is ready to proceed with pilot phase"
- "This is a sanctioned project with organizational commitment"

**Strategy 3: Connect to New Leadership's Agenda**
- ⚠️ **UNKNOWN:** Randall's priorities (efficiency? innovation? equity?)

**Action:** In first call, ask about priorities, then adapt messaging:
- If Randall prioritizes **efficiency:** "This pilot reduces compliance time by 30%, freeing staff for direct services"
- If Randall prioritizes **innovation:** "This pilot uses AI-powered insights to optimize program effectiveness"
- If Randall prioritizes **equity:** "This pilot ensures underserved populations get better data-driven services"

**Strategy 4: Showcase Broad Support and Results**
- ❌ **MISSING:** Data, testimonials, coalition-building

**Action:** Create "Whittier First Day Pilot Impact Projection":
- **Projected ROI:** $7.5K investment → $15K-30K in staff time saved
- **Testimonials:** (If available from other nonprofits using similar systems)
- **Coalition:** Program staff who support the pilot

**Strategy 5: Offer Quick Decision Pathways**
- ❌ **CURRENT:** Eric is passive (waiting for Randall to reach out)
- ✅ **TARGET:** Eric is proactive (making it easy for Randall to say yes)

**Action:** Send "One-Page Decision Brief" to Randall (via Rudy):
- **Background:** MoU signed Aug 27
- **Pilot:** 90 days, $7.5K, 30-day opt-out
- **ROI:** $15K-30K staff time saved
- **Next Step:** 30-min call to approve pilot start

---

## IMMEDIATE ACTION PLAN (NEXT 7 DAYS)

### Day 1 (Nov 7, Thu): Create Pilot Documents
1. **MoU Value Summary** (1 page) - Show measurable outcomes
2. **Pilot SOW** (2 pages) - Deliverables, timeline, success metrics
3. **Pilot Agreement** (1-2 pages) - Payment terms, milestones, opt-out clause
4. **Partnership Brief for Randall** (1 page) - Background, goals, status, next steps
5. **One-Page Decision Brief** (1 page) - Quick yes/no decision for Randall

### Day 2 (Nov 8, Fri): Email Rudy Garcia
```
Subject: Whittier First Day Pilot - Ready to Launch

Rudy,

Thanks for reaching out yesterday. I know Randall is taking some time off, so I wanted to make his decision as easy as possible when he returns.

I've prepared a complete pilot package (attached):
1. MoU Value Summary - What Whittier gets from this partnership
2. Pilot SOW - 90-day pilot, $7.5K, clear deliverables
3. Pilot Agreement - Simple contract with 30-day opt-out clause
4. Partnership Brief for Randall - Quick background and next steps

I'm also offering a FREE 1-week compliance audit (no cost, no obligation) to demonstrate value before the paid pilot starts. This way Randall can see results before committing.

Can you forward these to Randall and let me know when he's available for a 30-min call?

Alternatively, if it makes sense to brief program staff or board members in the meantime, I'm happy to do that.

Thanks,
Eric
```

### Day 3-5 (Nov 9-11, Sat-Mon): Wait for Response
- Monitor email for Rudy/Randall response
- If no response by Nov 11, follow up with Rudy

### Day 6 (Nov 12, Tue): Follow Up (If No Response)
```
Subject: Re: Whittier First Day Pilot - Ready to Launch

Rudy,

Following up on my Nov 8 email. I know Randall is busy, so I wanted to make sure this didn't get lost.

The pilot package is ready to go, and I'm still offering the free 1-week compliance audit to demonstrate value.

Is Randall back from his time off? If so, can we schedule a 30-min call this week?

If not, is there someone else (program staff, board member) I should connect with in the meantime?

Thanks,
Eric
```

### Day 7 (Nov 13, Wed): Assess Next Steps
- **If Randall responds:** Schedule call, present pilot SOW, aim for approval
- **If Rudy responds (Randall still out):** Offer to brief program staff, build coalition
- **If no response:** Pivot to other opportunities (ex parte, H Bui), revisit Whittier in 2-3 weeks

---

## SUCCESS METRICS (30 DAYS)

### Week 1 (Nov 7-13):
- ✅ Pilot documents created (SOW, agreement, brief)
- ✅ Email sent to Rudy Garcia
- ✅ Free compliance audit offered

### Week 2 (Nov 14-20):
- ✅ Randall Trice returns from time off
- ✅ 30-min call scheduled
- ✅ Pilot SOW presented

### Week 3 (Nov 21-27):
- ✅ Pilot approved by Randall
- ✅ Pilot agreement signed
- ✅ Month 1 payment received ($2.5K)

### Week 4 (Nov 28-Dec 4):
- ✅ Pilot launched (compliance dashboard delivered)
- ✅ Month 2 payment received ($2.5K)
- ✅ Total revenue: $5K (with $2.5K more in Month 3)

---

## REALISTIC PROBABILITY ASSESSMENT

### Current Status (Before Action Plan):
- **Probability:** 30-40% (lukewarm, waiting for Randall)
- **Timeline:** Unknown (Randall taking time off)
- **Revenue Potential:** $0-5K (uncertain)

### After Action Plan Execution:
- **Probability:** 50-60% (proactive, value demonstrated)
- **Timeline:** 2-3 weeks (Randall returns, call scheduled)
- **Revenue Potential:** $5K-7.5K (pilot approved, incremental payments)

### Key Success Factors:
1. **Free compliance audit** demonstrates value before asking for money
2. **30-day opt-out clause** reduces Randall's risk
3. **Milestone-based payments** make budget approval easier
4. **One-page decision brief** makes it easy for Randall to say yes
5. **Organizational framing** (not "Donna's project") ensures continuity

---

## ZAPIER AUTOMATION (SET UP AFTER EMAIL SENT)

### Gmail → Google Sheets
**Trigger:** New email from Rudy Garcia or Randall Trice  
**Action:** Add row to "Whittier Partnership Tracking" sheet with:
- Date received
- From (Rudy or Randall)
- Subject line
- Status (awaiting response, call scheduled, pilot approved)

### Google Calendar → Gmail
**Trigger:** 3 days after email sent (Nov 11)  
**Action:** Send reminder to Eric:
- "Follow up with Rudy Garcia - Whittier pilot proposal"
- Include link to original email
- Include link to Priority Dashboard

### Google Sheets → Google Docs
**Trigger:** Pilot approved (manual update in sheet)  
**Action:** Generate pilot tracking document:
- Pilot start date
- Month 1 deliverable (dashboard)
- Month 2 deliverable (reports)
- Month 3 deliverable (analysis)
- Payment schedule ($2.5K x 3)

---

## BOTTOM LINE

**CURRENT STATUS:** Lukewarm (30-40% probability, $0-5K revenue potential)

**AFTER ACTION PLAN:** Proactive (50-60% probability, $5K-7.5K revenue potential)

**KEY INSIGHT:** Eric is currently in passive position (waiting for Randall). Action plan shifts to proactive position (making it easy for Randall to say yes).

**CRITICAL SUCCESS FACTOR:** Free compliance audit (1-week, no cost) demonstrates value before asking for money. This is the "Quick Win" that converts 60-90% of pilots to paid contracts.

**NEXT STEP:** Create 5 pilot documents (Day 1), email Rudy Garcia (Day 2), offer free audit.

---

**END OF PLAYBOOK**
