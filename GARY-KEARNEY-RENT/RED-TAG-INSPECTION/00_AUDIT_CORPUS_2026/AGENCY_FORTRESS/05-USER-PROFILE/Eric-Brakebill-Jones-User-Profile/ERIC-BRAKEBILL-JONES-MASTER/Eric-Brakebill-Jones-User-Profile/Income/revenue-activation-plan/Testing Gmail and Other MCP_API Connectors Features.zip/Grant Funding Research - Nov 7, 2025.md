# Grant Funding Research - Nov 7, 2025

## Recovery Compass Eligibility Status

**501(c)(3) Status:** Recovery Compass (Jan 2025 launch)  
**Focus Areas:** Domestic violence advocacy, substance abuse recovery, evidence-based practice  
**Credentials:** MSW (Cal State LA, May 2025), international speaker (Cuba, India), published methodology

---

## TIER 1: Federal Grants (OVW - Office on Violence Against Women)

### OVW FY2025 Children and Youth Program
**Grant ID:** O-OVW-2025-172291  
**Amount:** $500,000 award ceiling, $9.5M total program funding  
**Deadline:** June 30, 2025  
**Eligibility:** ✅ Nonprofits with 501(c)(3) status (Recovery Compass qualifies)  
**Focus:** Prevention, intervention, treatment, response for ages 0-24 impacted by DV, dating violence, sexual assault, stalking, sex trafficking  
**Match Required:** No  
**Expected Awards:** 19 grants  
**Contact:** OVW.ChildrenYouth@usdoj.gov, 202-307-6026

**Timeline:** 7+ months (not emergency funding)  
**Strategic Value:** High credibility, large award, aligns with Recovery Compass mission  
**Action:** Bookmark for Q2 2025 application (not immediate cash flow solution)

### Other OVW Programs
**Source:** https://www.justice.gov/ovw/grant-programs  
**Programs:** Multiple grant programs for DV, dating violence, sexual assault, stalking  
**Typical Range:** $20K-500K per award  
**Typical Timeline:** 6-12 months application to award  
**Action:** Review all OVW programs for additional opportunities

---

## TIER 2: Foundation Grants (Faster Turnaround)

### Mary Kay Ash Foundation - Domestic Violence Shelter Grants
**Amount:** $20,000 per grant (minimum 1 per state)  
**Eligibility:** ✅ Nonprofits serving DV survivors  
**Restriction:** Recipients ineligible for back-to-back years  
**Timeline:** Unknown (need to research application cycle)  
**Strategic Value:** Moderate amount, state-level distribution increases odds  
**Action:** Research current application cycle and deadline

### Emergency Assistance Foundation
**Source:** https://emergencyassistancefdn.org/domesticviolence/  
**Focus:** Direct financial assistance to DV survivors  
**Eligibility:** ✅ Nonprofits supporting DV survivors  
**Amount:** Unknown (need to research)  
**Timeline:** Unknown (name suggests faster turnaround)  
**Action:** Contact foundation for application details

### STOP Grants (VAWA-funded)
**Average Award:** $47,626  
**Focus:** Victim services for sexual assault and DV  
**Funding Source:** Violence Against Women Act  
**Timeline:** Unknown (need to research current cycle)  
**Action:** Research state-level STOP grant administrator

---

## TIER 3: Web3 / Crypto Philanthropy (INNOVATIVE)

### Gitcoin Grants (Quadratic Funding)
**Mechanism:** Quadratic funding amplifies small donations (broad community support = higher matching funds)  
**Current Round:** GG24 (October 14-28, 2025) - **MISSED**  
**Next Round:** GG25 (estimated Q1 2026)  
**Platform:** Hosted on Giveth  
**Funding Models:** Quadratic funding, retro funding, conviction voting  
**2025 Strategy:** Dynamic QF, metrics-based funding, fairer distribution to early-stage projects  
**Strategic Value:** High - Recovery Compass is early-stage, perfect fit for QF model  
**Action:** 
1. Create Recovery Compass profile on Gitcoin
2. Build community support (social media, email list, partnerships)
3. Prepare for GG25 (Q1 2026)
4. Research retro funding and conviction voting opportunities (may have faster timelines)

**Typical Amounts:** Varies widely ($500-50K+ depending on community support and matching pool)

### The Giving Block + Endaoment
**Platform:** The Giving Block (crypto donation platform for nonprofits)  
**Integration:** Endaoment (501c3 foundation managing on-chain crypto donations)  
**Mechanism:** Nonprofits create profiles, donors search and donate crypto (auto-converted to cash)  
**Setup Time:** Immediate (create profile, start accepting donations)  
**Strategic Value:** Passive income stream, tap into crypto philanthropy market  
**Action:**
1. Create Recovery Compass profile on The Giving Block
2. Enable Endaoment integration (automatic)
3. Promote crypto donation option to network
4. Target crypto-native DV advocates, Web3 social impact communities

**Typical Amounts:** Varies ($100-10K+ per donation, depends on marketing and network)

### Impact DAOs (Decentralized Autonomous Organizations)
**Examples:** 
- UkraineDAO 2.0 (raised $7M+ in ETH for crisis response)
- Big Green DAO (food justice)
- Various women's rights / DV-focused DAOs

**Mechanism:** Community-governed funding, proposal-based grants, token-holder voting  
**Timeline:** Faster than traditional grants (days to weeks)  
**Strategic Value:** High - aligns with Recovery Compass innovation focus, DV advocacy mission  
**Action:**
1. Research active Impact DAOs focused on women's rights, DV, social justice
2. Join DAO communities (Discord, governance forums)
3. Submit funding proposals (typically $5K-50K range)
4. Build relationships with DAO members

**Typical Amounts:** $5K-50K per proposal (some DAOs have larger pools)

### Web3 Public Goods Funding Ecosystem
**Trend (2024-2025):** Growth in retroactive funding, self-sustaining models  
**Key Platforms:** Gitcoin, Giveth, Clr.fund, Octant  
**Funding Raised (Q2 2025):** $9.6B in Web3 infrastructure startups  
**Strategic Value:** Emerging market, less competition than traditional grants, aligns with Eric's tech innovation background  
**Action:**
1. Research retroactive funding opportunities (reward past impact, not just future plans)
2. Document Recovery Compass impact metrics (pilot results, testimonials, outcomes)
3. Apply for public goods funding (Recovery Compass = public good)

---

## TIER 4: Crowdfunding (IMMEDIATE)

### Kickstarter (Pro Per Defense Toolkit Pre-Sales)
**Model:** Product pre-sales (toolkit as reward for backers)  
**Timeline:** 30-60 day campaign  
**Typical Success Rate:** 37% (need strong marketing, network activation)  
**Typical Amount:** $5K-50K (depends on network size, product appeal)  
**Strategic Value:** Dual benefit (revenue + product validation)  
**Action:**
1. Finalize Pro Per Defense Toolkit (MVP version)
2. Create compelling Kickstarter campaign (video, story, rewards)
3. Set realistic goal ($10K-20K)
4. Activate network (email list, social media, partnerships)
5. Launch campaign (45-day duration)

**Estimated Timeline:** 2 weeks prep + 45 days campaign = 8 weeks total  
**Estimated Revenue:** $10K-30K (if successful)

### GoFundMe (Recovery Compass Operating Fund)
**Model:** Donation-based crowdfunding (no rewards required)  
**Timeline:** Ongoing (no deadline)  
**Typical Amount:** $5K-20K (depends on story, network, marketing)  
**Strategic Value:** Fast setup, flexible use of funds, emotional storytelling advantage  
**Action:**
1. Create compelling campaign (Eric's story, Recovery Compass mission, impact)
2. Leverage credentials (MSW, international speaker, 501c3 founder)
3. Share widely (social media, email, partnerships, conferences)
4. Update regularly (progress, impact, gratitude)

**Estimated Timeline:** 1 week setup + ongoing promotion  
**Estimated Revenue:** $5K-15K (over 30-60 days with active promotion)

### Indiegogo (Case Study Publication)
**Model:** Product pre-sales (case studies, guides, templates as rewards)  
**Timeline:** 30-60 day campaign  
**Typical Amount:** $5K-30K (depends on product appeal, network)  
**Strategic Value:** Monetize IP (Kirk case study, Mom's estate case study, etc.)  
**Action:**
1. Package case studies (anonymized, educational value)
2. Create campaign (legal education focus, CLE potential)
3. Target attorneys, law students, pro per litigants
4. Launch campaign

**Estimated Timeline:** 3 weeks prep + 60 days campaign = 11 weeks total  
**Estimated Revenue:** $5K-15K (if successful)

---

## TIER 5: Emergency / Rapid Response Grants (RESEARCH NEEDED)

**Search Terms:**
- "Emergency grant domestic violence"
- "Rapid response funding nonprofit"
- "Crisis funding social services"
- "Fast-track grant DV advocacy"

**Target Characteristics:**
- 7-15 day turnaround (application to decision)
- $5K-10K award range
- 501(c)(3) eligible
- DV / substance abuse / social work focus

**Action:** Deep research needed (Candid/Foundation Directory, GrantWatch, nonprofit forums)

---

## STRATEGIC RECOMMENDATIONS

### Immediate (7-15 Days) - $5K-10K Potential
1. **Create The Giving Block profile** (1 day setup, passive crypto donations)
2. **Launch GoFundMe campaign** (1 week setup, ongoing revenue)
3. **Research emergency grants** (deep dive into rapid response funders)

### Short-Term (15-30 Days) - $10K-20K Potential
4. **Join 2-3 Impact DAOs** (submit funding proposals)
5. **Apply for Mary Kay Ash Foundation grant** (if cycle is open)
6. **Launch Kickstarter for Pro Per Defense Toolkit** (if toolkit is ready)

### Medium-Term (30-60 Days) - $10K-30K Potential
7. **Apply for STOP grants** (state-level VAWA funding)
8. **Submit OVW grant applications** (multiple programs)
9. **Launch Indiegogo for case studies** (if IP is ready)

### Long-Term (60+ Days) - $20K-100K Potential
10. **Prepare for Gitcoin GG25** (Q1 2026, build community now)
11. **Apply for large foundation grants** ($50K-500K range)
12. **Develop Web3 public goods funding strategy** (retroactive funding, self-sustaining models)

---

## CRITICAL GAPS (NEED RESEARCH)

1. **Emergency grant database:** Which funders offer 7-15 day turnaround?
2. **Mary Kay Ash Foundation cycle:** When is next application deadline?
3. **STOP grants:** Who is California's state administrator? What is current cycle?
4. **Impact DAOs:** Which DAOs are actively funding DV / women's rights projects?
5. **Retroactive funding:** Which platforms offer retro funding for past impact?
6. **Recovery Compass 501(c)(3) docs:** Where is EIN, IRS determination letter, founding docs?

---

## NEXT STEPS

**Manus to execute:**
1. Deep research on emergency grants (7-15 day turnaround)
2. Identify active Impact DAOs for DV / women's rights
3. Research retroactive funding platforms
4. Find California STOP grant administrator
5. Verify Mary Kay Ash Foundation application cycle

**Eric to execute:**
1. Gather Recovery Compass 501(c)(3) documentation (EIN, IRS letter)
2. Document pilot results (Whittier First Day, Amity Foundation)
3. Prepare compelling story (GoFundMe, Kickstarter campaigns)
4. Finalize Pro Per Defense Toolkit (MVP version for pre-sales)
5. Create The Giving Block profile (crypto donations)

**GCM to execute:**
1. Search for all Recovery Compass 501(c)(3) documents (Google Drive, Desktop, Gmail)
2. Find pilot results, testimonials, impact metrics (Whittier, Amity, Justice Care)
3. Locate any existing grant applications or proposals (templates for future use)
4. Identify network contacts (potential donors, partners, advocates)
