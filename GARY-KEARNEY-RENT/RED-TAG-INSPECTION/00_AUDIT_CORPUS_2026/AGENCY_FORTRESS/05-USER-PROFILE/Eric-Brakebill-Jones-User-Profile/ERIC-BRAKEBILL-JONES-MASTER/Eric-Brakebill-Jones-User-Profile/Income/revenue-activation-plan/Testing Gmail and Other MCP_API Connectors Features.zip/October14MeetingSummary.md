# **🌸 10-14\_A\_Nuha and Kirk and Sean\_Domestic Violence Case Preparation**

## **Transcript**

[https://otter.ai/u/v1ymXyMd8-Ml-6APDwhweO5W09k?view=summary](https://otter.ai/u/v1ymXyMd8-Ml-6APDwhweO5W09k?view=summary)

Nuha Sayegh and her legal team, including Kirk Kolodji and Sean Kolodji, discussed the preparation for a domestic violence case involving Nuha's husband. They reviewed photos and timestamps, noting discrepancies in the dates of incidents, particularly a headbutt incident on November 3, 2023\. Nuha admitted to not remembering exact dates and to having taken a photo of her lips as a joke. They also discussed Nuha's income, which was estimated at $5,500 a month, and the need to update financial records. The team emphasized the importance of accurate timelines and evidence for the upcoming court hearing. Nuha Sayegh and Sean Kolodji discussed Nuha's domestic violence case, focusing on her financial situation and the timeline of events. Nuha mentioned receiving $1,500 from Eric but facing financial difficulties. She detailed her interactions with her ex-husband, Fahad, and his visits from January 2022 to September 2022\. Nuha also recounted her drug use, including a fentanyl incident in October 2021, and her subsequent detox at Las Encinas. Sean emphasized the importance of accurate financial records and potential witness testimonies, including Joyce and Deputy Reyes, to support Nuha's case.

## **Action Items**

* \[ \] @Nuha Sayegh \- Update the income and expense declaration with the participant's actual income information.  
* \[ \] @Nuha Sayegh \- Print out the bank statements and payment records to attach to the income and expense declaration.  
* \[ \] Ensure the participant is sober and focused for the court hearing the next day.  
* \[ \] Finalize the timeline and evidence for the domestic violence incidents.

## **Outline**

### **Evidence and Legal Strategy Discussion**

* Sean Kolodji (paralegal) explains the detective's inability to share evidence but suggests Nuha Sayegh contact the detective for potential criminal charges related to the August incident.  
* Nuha Sayegh and Kirk Kolodji (Nuha's lawyer) discuss the importance of focusing on specific allegations and the potential use of documents in Nuha's civil case.  
* Nuha Sayegh mentions receiving a missed call from Detective Cordova and attempts to contact her.  
* Kirk Kolodji (Nuha's lawyer) and Sean Kolodji (paralegal) discuss the timeline and context of photos Nuha sent, which show injuries and potential miscommunications about the incidents.

### **Reviewing and Clarifying Incident Details**

* Nuha Sayegh and Sean Kolodji (paralegal) review photos and discuss the timeline of incidents, including a headbutt and other physical injuries.  
* Nuha Sayegh clarifies that she did not remember the exact dates of some incidents and had only seen some photos after the fact.  
* Kirk Kolodji (Nuha's lawyer) emphasizes the importance of accurate timelines and the potential impact of discrepancies on the case.  
* Nuha Sayegh and Sean Kolodji (paralegal) discuss the significance of specific photos and the need to correct any inaccuracies in the timeline.

### **Addressing Legal Documentation and Evidence**

* Nuha Sayegh and Kirk Kolodji (Nuha's lawyer) discuss the need to download and organize all filed documents and pleadings.  
* Nuha Sayegh mentions finding additional photos that were not initially included in the evidence.  
* Kirk Kolodji (Nuha's lawyer) advises Nuha to focus on the most recent incidents and to ensure all evidence is properly documented and dated.  
* Sean Kolodji (paralegal) and Nuha Sayegh discuss the importance of having detailed records and the potential impact of missing or inaccurate information on the case.

### **Preparing for Court and Legal Strategy**

* Kirk Kolodji (Nuha's lawyer) advises Nuha to prepare for court by being calm, sober, and truthful in her testimony.  
* Nuha Sayegh and Kirk Kolodji (Nuha's lawyer) discuss the potential for a continuance and the importance of being ready for any legal proceedings.  
* Sean Kolodji (paralegal) and Nuha Sayegh review the timeline of incidents and the need to present clear and accurate evidence in court.  
* Kirk Kolodji (Nuha's lawyer) emphasizes the importance of focusing on physical violence and avoiding distractions or irrelevant details during the hearing.

### **Reviewing Property and Financial Records**

* Nuha Sayegh and Kirk Kolodji (Nuha's lawyer) discuss the properties owned by Nuha's husband and the need to accurately document them for the case.  
* Nuha Sayegh provides addresses and details about the properties, including those owned by her husband's family.  
* Kirk Kolodji (Nuha's lawyer) advises Nuha to focus on the properties owned by her husband and to ensure all relevant financial records are included in the case.  
* Sean Kolodji (paralegal) and Nuha Sayegh discuss the importance of accurate financial records and the potential impact of property ownership on the case.

### **Finalizing Legal Preparations and Next Steps**

* Kirk Kolodji (Nuha's lawyer) advises Nuha to finalize her income and expense declaration and to ensure all relevant financial records are included.  
* Nuha Sayegh and Kirk Kolodji (Nuha's lawyer) discuss the importance of being prepared for court and the need to focus on the most relevant details of the case.  
* Sean Kolodji (paralegal) and Nuha Sayegh review the timeline of incidents and the need to present clear and accurate evidence in court.  
* Kirk Kolodji (Nuha's lawyer) emphasizes the importance of being calm, sober, and truthful in court and advises Nuha to focus on the most recent incidents and to avoid distractions or irrelevant details.

### **Nuha's Transportation and Apology**

* Nuha mentions figuring out a way to Uber her kids to school.  
* Sean Kolodji apologizes for being aggressive during questioning.  
* Nuha reassures Sean that it's fine and appreciates the apology.  
* Sean emphasizes the importance of a good narrative for the case.

### **Financial Support and Temporary Restraining Order**

* Sean discusses the importance of accurate financial statements for a potential temporary restraining order.  
* Nuha mentions receiving $1,500 from Eric, but he hasn't responded.  
* Sean expresses hope that Kirk can provide Nuha with some financial support.  
* Nuha shares her frustration over Eric's lack of communication and financial support.

### **Timeline of Fahad's Visits**

* Sean asks about Fahad's visits from January 19, 2022, to September 2022\.  
* Nuha describes Fahad's visits, including dinner, hanging out with the kids, and sleeping over.  
* Nuha mentions parking Fahad's car a block away to keep visits quiet.  
* Sean notes the incriminating material Fahad included in his statements.

### **Incident with Fentanyl and Drug Use**

* Nuha clarifies a past incident where she was caught with benzos, not fentanyl.  
* Sean and Nuha discuss the timeline of her drug use and detox experiences.  
* Nuha shares her experience with fentanyl and the severe consequences she faced.  
* Sean asks about Nuha's current possession of drugs and her plans to retrieve them.

### **Witnesses and Incident Details**

* Nuha mentions witnesses like Deputy Reyes and Camilla, who called the cops.  
* Sean and Nuha discuss the timeline of the incident and the deletion of Camilla's number from Nuha's phone.  
* Nuha shares details about her father and father-in-law's involvement in her abuse.  
* Sean emphasizes the importance of having Joyce testify about the night of the incident.

### **Nuha's Mental Health and Drug Use**

* Nuha talks about her mental health issues and the abuse of antidepressants.  
* Sean clarifies the difference between antidepressants and other drugs Nuha was taking.  
* Nuha explains her mistake of thinking fentanyl was oxycodone.  
* Sean and Nuha discuss the impact of the fentanyl incident on her mental health and subsequent detox.

### **Logistics and Coordination**

* Nuha coordinates with Sean to pick up her kids from school.  
* Sean provides Nuha with the address and instructions for the pickup.  
* Nuha updates Sean on her kids' whereabouts and the logistics of the pickup.  
* Sean and Nuha discuss the importance of accurate timelines and financial records for the case.

### **Nuha's Abuse and Family Dynamics**

* Nuha shares details about her father's encouragement of abuse and her father-in-law's involvement.  
* Sean emphasizes the importance of Joyce's testimony about the abuse Nuha suffered.  
* Nuha describes the physical and emotional toll of the abuse she endured.  
* Sean reassures Nuha that her narrative is believable and important for the case.

### **Financial Records and Support**

* Nuha sends Sean her bank statement and pay stubs to document financial support.  
* Sean discusses the importance of accurate financial records for the case.  
* Nuha mentions her expenses, including car and health insurance.  
* Sean and Nuha discuss the need for better financial support and documentation.

### **Coordination with Lawyer and Family**

* Nuha coordinates with her lawyer, Kirk, about the case.  
* Sean and Nuha discuss the importance of accurate financial records and support.  
* Nuha updates Sean on her kids' return and the logistics of the pickup.  
* Sean and Nuha emphasize the importance of accurate timelines and financial records for the case.

Based on the meeting transcript, here are the ethics/conduct findings for the CA Ethics/Conduct Flags — Kolodji Matter:

## **Key Findings**

### **Role/Authority Claims**

* **Sean Kolodji** consistently identifies himself as a "paralegal" throughout the meeting  
* **Kirk Kolodji** is clearly identified as "Nuha's lawyer" and the attorney handling the case  
* No instances found of Sean claiming attorney status or legal authority

### **Legal Advice by Non-Lawyer**

**Multiple instances identified:**

**Speaker:** Sean Kolodji (paralegal) **Claimed Role/Title:** Paralegal **Directive/Advice Given:**

* "we don't really want to get involved" (regarding criminal case)  
* "just getting documents for her that can Sure, sure"  
* "I don't know that those are useful because that that I think it's absurd"  
* Extensive questioning and case strategy discussions **Conditioning Event:** None explicit **Confidence:** High \- Sean provides substantial case analysis and strategic guidance

### **Staff Acting as Counsel**

**Speaker:** Sean Kolodji (paralegal) **Claimed Role/Title:** Paralegal **Directive/Advice Given:**

* Conducting extensive client interview  
* Making strategic recommendations about evidence  
* Directing case preparation activities **Follow-up Needed:** Yes \- Review scope of paralegal activities vs. attorney supervision

### **Fee/Scope Ambiguity**

**Multiple references to financial arrangements:**

* Discussion of $5,500 monthly income discrepancies  
* References to Eric bringing "cash" and "money"  
* No clear fee agreement discussion captured in transcript **Confidence:** Medium \- Financial arrangements discussed but fee structure unclear

### **Third-Party Payor Issues**

**Speaker:** Various **Directive/Advice Given:** References to "Eric was supposed to bring in the rest of that money today" **Conditioning Event:** Payment expectations from third party (Eric) **Follow-up Needed:** Yes \- Clarify payment source and any privilege implications

### **Address/Office Variance**

**Address referenced:** Multiple locations mentioned:

* "75 North Korea" (appears to be transcription error)  
* "5656 Moringa"  
* Various property addresses discussed **Confidence:** Low \- Addresses unclear due to transcription quality

### **Competence/Strategy Issues**

**Extensive strategy discussions including:**

* Evidence preparation and timeline issues  
* Witness coordination  
* Case preparation concerns  
* Kirk expressing concerns about readiness: "I don't think we're ready for an evidentiary hearing"

### **Communication/Documentation Issues**

* Timeline discrepancies in evidence noted  
* Concerns about case preparation adequacy  
* Multiple references to missing or unclear documentation

## **Labels Applied**

* **UPL\_Risk:** Medium (Sean's extensive case guidance)  
* **Staff\_Supervision:** High concern (extensive paralegal activities)  
* **Fee\_Scope:** Medium (unclear fee arrangements)  
* **ThirdParty\_Conflict:** Medium (Eric as payor)  
* **Competence:** High (attorney expressing readiness concerns)  
* **Communication\_Duty:** High (timeline and evidence issues)

## **Auto-Bookmark Recommendations**

* Sean's strategic advice segments (UPL\_Risk)  
* Financial arrangement discussions (Fee\_Scope)  
* Third-party payment references (ThirdParty\_Conflict)

