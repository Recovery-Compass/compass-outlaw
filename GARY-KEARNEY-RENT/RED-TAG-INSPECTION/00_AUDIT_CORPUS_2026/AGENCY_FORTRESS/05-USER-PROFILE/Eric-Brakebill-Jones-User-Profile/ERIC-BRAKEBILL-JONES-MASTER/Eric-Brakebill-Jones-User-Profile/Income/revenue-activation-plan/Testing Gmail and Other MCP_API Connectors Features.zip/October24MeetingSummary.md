# **10-24\_Phone meeting between Nuha Saygh and Kirk Kolodji (Nuha's lawyer)**

## **Transcript**

[https://otter.ai/u/i3x2UipQ9dW-vaeLQqUlED5f-Lw?view=summary](https://otter.ai/u/i3x2UipQ9dW-vaeLQqUlED5f-Lw?view=summary)

Nuha Sayegh and her lawyer, Kirk Kolodji, discussed her ongoing legal case and financial struggles. Nuha expressed frustration over her father's behavior and her limited income, which she estimated at $1,000-$1,500 per month. Kirk emphasized the need for Nuha to complete an income and expense declaration and warned against emotional responses that could harm her case. They reviewed Nuha's expenses, including $5,600 rent, $2,200 for renters insurance, and $1,800 for groceries. Kirk advised Nuha to seek therapy and suggested negotiating a settlement with her ex-husband for $7,200 per month to cover her expenses.

## **Action Items**

* \[ \] @Nuha Sayegh \- Update the income and expense declaration with Nuha's actual monthly income of around $1,000-$1,500.  
* \[ \] @Nuha Sayegh \- Provide Kirk with Nuha's bank statements to support the lower income amount.  
* \[ \] @Nuha Sayegh \- Discuss the possibility of Freddie agreeing to pay Nuha $7,200 per month in support, to avoid the need for the hearing.  
* \[ \] Clarify with Freddie that he should not have submitted any documentation about Nuha's income without her consent.  
* \[ \] File the updated income and expense declaration and any other necessary documents for the upcoming hearing.

## **Outline**

### **Nuha's Emotional State and Communication Issues**

* Nuha Sayegh expresses her emotional distress, mentioning her father's behavior and the impact of her mother's influence.  
* Kirk Kolodji advises Nuha to continue working with him for better legal outcomes, despite her frustration.  
* Nuha admits to replying to Freddie despite being warned not to, which complicates her case due to the restraining order.  
* Kirk emphasizes the importance of cooperation and warns against emotional responses that could harm her case.

### **Legal Requirements and Financial Disputes**

* Kirk explains the need for Nuha to complete an income and expense declaration to proceed with her case.  
* Nuha is upset about Eric's emails and the potential threat to Kirk's bar license, which Kirk dismisses as unfounded.  
* Kirk outlines the upcoming hearing in November, where they will seek attorney fees, child support, and spousal support.  
* Nuha is concerned about her financial situation and the lack of money to live on, expressing frustration with Eric's financial support.

### **Bank Statements and Income Clarification**

* Nuha and Kirk discuss her bank statements, which show inconsistent income and frequent payments from Eric.  
* Kirk calculates Nuha's average monthly income based on her bank deposits, which Nuha disputes, claiming much of it is repayment from Eric.  
* Nuha provides additional details about her expenses, including rent, utilities, and other living costs.  
* Kirk highlights the need for Nuha's income and expenses to align with her legal declarations to avoid complications in court.

### **Legal Strategy and Emotional Outbursts**

* Kirk advises Nuha to avoid making threatening statements, as it could jeopardize her case.  
* Nuha expresses her frustration and anger, feeling betrayed by everyone involved in her case.  
* Kirk reassures Nuha of his commitment to her case and advises her to seek therapy to cope with her emotional turmoil.  
* Nuha discusses her financial struggles, including her reliance on Eric's financial support and the challenges of maintaining her living expenses.

### **Finalizing Financial Declarations**

* Nuha and Kirk continue to discuss her income and expenses, with Nuha providing detailed breakdowns of her financial situation.  
* Kirk emphasizes the importance of accurate financial declarations to support Nuha's case in court.  
* Nuha expresses her frustration with Eric's financial support and the impact it has on her ability to live independently.  
* Kirk advises Nuha to focus on providing clear and accurate financial information to avoid further complications in her case.

Based on the transcript analysis, here are the findings for the CA Ethics/Conduct Flags — Kolodji Matter:

## **Entity Tracking Results**

**Present in transcript:**

* Kirk Kolodji (Nuha's attorney)  
* Eric (mentioned as sending hostile emails and involved in the case)  
* Nuha Sayegh (client)  
* Freddy/Fahed Sayegh (husband in divorce case)  
* Jennifer (mentioned briefly \- "Hi, Jennifer, how are you doing?")

**Not mentioned in transcript:**

* Sean Kolodji  
* Kolodji Family Law  
* Eric Jones (only "Eric" mentioned)  
* DCFS  
* Clio  
* LawPay

## **Key Pattern Analysis**

### **Fee/Scope Ambiguity \- HIGH CONFIDENCE**

**Speaker:** Kirk Kolodji  
 **Directive/Advice Given:** "I at this point, I understand you can't pay me, so I'm going to have to seek fees from him, which I'm happy to do. I need your cooperation to do that."  
 **Labels:** Fee\_Scope, ThirdParty\_Conflict  
 **Follow-up Needed:** Yes \- Fee arrangement unclear, seeking fees from opposing party

### **Third-Party Payor/Privilege \- HIGH CONFIDENCE**

**Speaker:** Kirk Kolodji  
 **Directive/Advice Given:** "Eric has involved himself very heavily in this litigation... They're going to try to get from him. They're going to put him with a court reporter there and ask them questions for eight hours"  
 **Labels:** ThirdParty\_Conflict, Privilege\_Risk  
 **Follow-up Needed:** Yes \- Third party Eric heavily involved, potential deposition risk

### **Pressure Language \- MEDIUM CONFIDENCE**

**Speaker:** Kirk Kolodji  
 **Directive/Advice Given:** "I just need at least some cooperation... But this sort of stuff where he's trying to come after my bar license"  
 **Conditioning Event:** Cooperation required before proceeding  
 **Labels:** Pressure\_Tactics, Communication\_Duty  
 **Follow-up Needed:** Yes \- Attorney expressing pressure about bar complaints

### **Communication Duty Issues \- HIGH CONFIDENCE**

**Speaker:** Kirk Kolodji  
 **Directive/Advice Given:** "you're not allowed to communicate with his attorney while I remain your attorney of record"  
 **Labels:** Communication\_Duty, Competence  
 **Follow-up Needed:** Yes \- Client communication restrictions unclear

### **Competence/Strategy Concerns \- MEDIUM CONFIDENCE**

**Speaker:** Kirk Kolodji  
 **Directive/Advice Given:** "I need your income and expense declaration... we have deadlines, we have a hearing coming up"  
 **Labels:** Competence, Communication\_Duty  
 **Follow-up Needed:** Yes \- Preparation issues for upcoming hearing

## **Auto-Bookmark Triggers**

* ThirdParty\_Conflict: Eric's heavy involvement in litigation  
* Fee\_Scope: Unclear payment arrangement and seeking fees from opposing party  
* Privilege\_Risk: Third party Eric subject to potential deposition

## **Additional Red Flags**

* Client expressing extreme frustration: "I want to kill him" (repeated threats)  
* Attorney advising against such statements for case protection  
* Emotional client communications affecting case strategy  
* Complex financial disclosure issues affecting support calculations

