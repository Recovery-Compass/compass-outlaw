# Ex Parte Filing Action Plan - Mom's Estate
**Date:** November 7, 2025  
**Case:** 21435809 (Los Angeles County Probate Court)  
**Status:** Files corrected, waiting for Anuar to submit OR Eric files himself

---

## PROVEN FRAMEWORK (From Top 2% Pro Per Litigants)

### COMPLETE FILING CHECKLIST

**Required Documents:**
1. ✅ Ex Parte Application (01_Ex_Parte_Application.pdf) - CORRECTED Nov 6
2. ✅ Declaration with Exhibits (02_Declaration_with_Exhibits.pdf) - CORRECTED Nov 6
3. ✅ Declaration for Good Cause Exception to Notice (03a_Declaration_for_Good_Cause_Exception_to_Notice.pdf) - CORRECTED Nov 6
4. ✅ Memorandum of Points and Authorities (04_MPA.pdf) - CORRECTED Nov 6
5. ✅ Proposed TRO/OSC (05_Proposed_TRO_OSC.pdf) - CORRECTED Nov 6
6. ✅ Petition 850 (06_Petition_850.pdf) - CORRECTED Nov 6
7. ✅ Probate Case Cover Sheet (07_Probate_Case_Cover_Sheet.pdf) - CORRECTED Nov 6

**Formatting Requirements (California Rules of Court 2.111):**
- ✅ Margins: At least 1 inch (top, bottom, both sides)
- ✅ Font: Not smaller than 12-point
- ✅ Spacing: Double-spaced (except code sections, quotations, footnotes)
- ✅ Page numbering: Consecutively numbered at bottom
- ✅ Exhibits: Attached as separate, clearly marked documents, bookmarked if e-filing
- ✅ Title page: Court name/address, case number, party names, document title

**Notice Requirements:**
- ⚠️ Serve all persons entitled to notice **no later than 10:00 AM the day before hearing**
- ⚠️ Email notice only valid with written consent filed in court
- ⚠️ Notify parties of "non-appearance" and "ruling on the papers" unless court orders hearing

**Filing Deadline:**
- ⚠️ File by **10:00 AM the day before** desired hearing (or at least 24 hours prior via drop box)
- ⚠️ Select "ex parte" as document type when e-filing

**Page Limit:**
- ✅ Application/opposition may not exceed **10 pages** (excluding attachments)

---

## COMMON REJECTION REASONS & SOLUTIONS

### 1. Insufficient Factual Showing
**Problem:** Not providing detailed, credible facts establishing urgency/irreparable harm  
**Solution:** Attach specific, factual declaration with supporting evidence

**Eric's Status:** ✅ SOLVED (02_Declaration_with_Exhibits.pdf includes detailed facts)

### 2. Failure to Give Proper Notice
**Problem:** Not serving all required parties, not showing proof, or serving too late  
**Solution:** Carefully follow local/statutory notice rules, document every step with declarations and proof of service

**Eric's Status:** ⚠️ NEEDS VERIFICATION (Check if notice requirements apply to this ex parte)

### 3. Missing or Improperly Formatted Documents
**Problem:** No proposed order, missing captions, omitted bookmarks, exceeding page limits  
**Solution:** Use checklist and model documents on judicial council/law library samples

**Eric's Status:** ✅ SOLVED (All 7 documents corrected Nov 6, formatting fixed per CRC 2.111)

### 4. Documents Not Compliant with CRC 2.111 Formatting
**Problem:** Incorrect margins, font size, spacing, page numbering  
**Solution:** See Formatting Requirements above

**Eric's Status:** ✅ SOLVED (Clerk said "refer to CRC 2.111 on how to format first page" - Eric corrected this Nov 6)

### 5. Application Filed After Deadline
**Problem:** Late filing deferred to next available day  
**Solution:** File as early as possible, confirm deadlines with local court rules

**Eric's Status:** ⚠️ AT RISK (Files ready Nov 6, but Anuar hasn't confirmed submission as of Nov 7)

### 6. Notice by Email Only Without Consent
**Problem:** Email notice not valid without written consent  
**Solution:** Serve via acceptable means or obtain/submit party's written consent

**Eric's Status:** ⚠️ NEEDS VERIFICATION (Check if notice requirements apply)

---

## TIMELINE EXPECTATIONS

| Step | Typical Timing | Eric's Status |
|------|----------------|---------------|
| **Serve/Notice parties** | No later than 10:00 AM the day before hearing | ⚠️ NEEDS VERIFICATION |
| **File ex parte packet** | By 10:00 AM the day before (or at least 24 hours prior via drop box) | ⚠️ WAITING FOR ANUAR (or Eric files himself) |
| **Court ruling** | Usually within 1-2 court days (decided "on the papers" without appearance, outcome sent by email/mail) | ⏳ PENDING FILING |
| **Distribution (effectuation)** | Depends on relief requested; emergency orders effective upon signature | ⏳ PENDING APPROVAL |

**REALISTIC TIMELINE (If Filed Today):**
- **Nov 7 (Thu):** File ex parte packet by 10:00 AM
- **Nov 8-9 (Fri-Sat):** Court ruling (1-2 court days)
- **Nov 10-15 (Sun-Fri):** Distribution process begins (if approved)
- **Nov 15-22 (Fri-Fri):** Distribution received ($5K-20K)

**TOTAL: 8-15 days from filing to distribution**

---

## IMMEDIATE ACTION PLAN (NEXT 24 HOURS)

### OPTION A: Wait for Anuar (RISKY)
**Timeline:**
- Nov 7, 8:00 AM: Follow up with Anuar (email + phone call)
- Nov 7, 5:00 PM: If no response, prepare to file yourself
- Nov 8, 8:00 AM: File yourself if Anuar still hasn't responded

**Risk:** Loses 1-2 days, may miss optimal filing window

### OPTION B: File Yourself TODAY (RECOMMENDED)
**Timeline:**
- Nov 7, 8:00 AM: Verify all 7 documents are CRC 2.111 compliant
- Nov 7, 9:00 AM: Verify notice requirements (if any)
- Nov 7, 10:00 AM: E-file all 7 documents (select "ex parte" as document type)
- Nov 7, 11:00 AM: Confirm filing accepted
- Nov 7, 12:00 PM: Email Anuar: "Filed myself to keep things moving, thanks for your help"

**Benefit:** Gains 1-2 days, maximizes chance of approval before weekend

---

## FILING INSTRUCTIONS (FOR ERIC TO FILE HIMSELF)

### Step 1: Verify Documents (30 minutes)
1. Open all 7 PDFs (01-07)
2. Check first page of each:
   - ✅ Court name/address listed
   - ✅ Case number 21435809
   - ✅ Party names (Eric B Jones, Judy Brakebill Jones Trust)
   - ✅ Document title
3. Check formatting:
   - ✅ 1-inch margins (all sides)
   - ✅ 12-point font or larger
   - ✅ Double-spaced (except quotes/footnotes)
   - ✅ Page numbers at bottom
4. Check page count:
   - ✅ Application ≤ 10 pages (excluding attachments)

### Step 2: Verify Notice Requirements (15 minutes)
1. Review ex parte application for notice language
2. Check if "good cause exception to notice" applies (03a document)
3. If notice required:
   - Serve all parties by 10:00 AM day before hearing
   - File proof of service
4. If notice exception applies:
   - Proceed to filing (no service required)

### Step 3: E-File Documents (30 minutes)
1. Go to Los Angeles County Probate Court e-filing portal
2. Log in with Eric's account
3. Select case 21435809
4. Upload all 7 documents:
   - 01_Ex_Parte_Application.pdf
   - 02_Declaration_with_Exhibits.pdf
   - 03a_Declaration_for_Good_Cause_Exception_to_Notice.pdf
   - 04_MPA.pdf
   - 05_Proposed_TRO_OSC.pdf
   - 06_Petition_850.pdf
   - 07_Probate_Case_Cover_Sheet.pdf
5. Select "ex parte" as document type for each
6. Submit filing
7. Save confirmation email/receipt

### Step 4: Confirm Filing Accepted (15 minutes)
1. Check email for filing confirmation
2. If rejected, review rejection notice
3. If accepted, note hearing date/time (if any)
4. Set calendar reminder for court ruling (1-2 court days)

### Step 5: Email Anuar (5 minutes)
```
Subject: Ex Parte Filed - Case 21435809

Anuar,

I filed the ex parte application myself today to keep things moving. All 7 corrected documents were submitted via e-filing portal at [TIME].

Filing confirmation: [ATTACH RECEIPT]

Thanks for your help getting the documents formatted correctly. I'll keep you posted on the court's ruling.

Eric
```

---

## SUCCESS METRICS

### Immediate (24 Hours):
- ✅ Ex parte packet filed by 10:00 AM Nov 7
- ✅ Filing confirmation received
- ✅ Anuar notified

### Short-Term (1-2 Court Days):
- ✅ Court ruling received (approved or denied)
- ✅ If approved: Distribution process begins
- ✅ If denied: Understand reason, prepare to refile

### Medium-Term (7-15 Days):
- ✅ Distribution received ($5K-20K)
- ✅ Funds deposited in Eric's account
- ✅ $11K runway extended to $16K-31K

---

## ZAPIER AUTOMATION (SET UP AFTER FILING)

### Gmail → Google Sheets
**Trigger:** New email from Los Angeles County Probate Court  
**Action:** Add row to "Ex Parte Tracking" sheet with:
- Date received
- Subject line
- Status (filed, approved, denied, distributed)
- Amount (if distribution notice)

### Google Calendar → Gmail
**Trigger:** 1-2 court days after filing  
**Action:** Send reminder email to Eric:
- "Check for ex parte ruling - Case 21435809"
- Include link to court e-filing portal
- Include link to Priority Dashboard

### Google Sheets → Google Docs
**Trigger:** Ex parte approved (manual update in sheet)  
**Action:** Generate distribution tracking document:
- Approval date
- Expected distribution date (7-15 days)
- Amount ($5K-20K)
- Next steps (wait for check, deposit, update runway)

---

## BOTTOM LINE

**RECOMMENDATION: FILE YOURSELF TODAY (OPTION B)**

**Why:**
- Files are ready (corrected Nov 6)
- Anuar hasn't responded in 24+ hours
- Every day of delay = 1 day later distribution
- Eric has all documents and knows the process

**Timeline if Filed Today:**
- Nov 7: File by 10:00 AM
- Nov 8-9: Court ruling
- Nov 15-22: Distribution received ($5K-20K)

**Timeline if Wait for Anuar:**
- Nov 7: Wait for response
- Nov 8: Anuar files (if responds)
- Nov 9-10: Court ruling
- Nov 16-23: Distribution received ($5K-20K)

**Difference: 1-2 days = $0 revenue impact, but reduces stress/uncertainty**

**ACTION: File yourself at 10:00 AM today, email Anuar confirmation.**

---

**END OF ACTION PLAN**
