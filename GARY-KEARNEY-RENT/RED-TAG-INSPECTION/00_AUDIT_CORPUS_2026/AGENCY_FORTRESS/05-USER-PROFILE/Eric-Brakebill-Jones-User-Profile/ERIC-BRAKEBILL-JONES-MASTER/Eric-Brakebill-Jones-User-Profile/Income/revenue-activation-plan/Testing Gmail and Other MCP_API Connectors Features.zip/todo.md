# Subscription Automation Platform - TODO

## Phase 1: Core Infrastructure
- [x] Database schema for subscriptions tracking
- [x] Database schema for recovery pipeline
- [x] Database schema for email templates
- [x] Database helper functions (40+ CRUD operations)
- [x] tRPC API procedures for all features

## Phase 2: Gmail MCP Integration (Subscription Discovery)
- [ ] Gmail MCP search for subscription invoices and receipts
- [ ] Parse email data to extract vendor, amount, frequency
- [ ] Detect duplicate subscriptions (same vendor, multiple accounts)
- [ ] Build protected tools list (MANUS, Otter, Scribd, Google Workspace, Claude, Perplexity, GitHub Copilot, Canva)
- [ ] Implement last 7 days usage filter
- [ ] Create subscription discovery dashboard

## Phase 3: Intelligent Analysis Engine
- [ ] Cost ranking algorithm (highest to lowest)
- [ ] Usage detection (last login, activity patterns)
- [ ] Consolidation opportunity detector (multiple tools → one replacement)
- [ ] Solo founder anomaly detection (team features, duplicate accounts)
- [ ] Confidence scoring (0-100) for each recommendation

## Phase 4: Trauma-Informed Dashboard UI
- [ ] Minimalist sanctuary-style design
- [ ] Subscription audit results view
- [ ] Human-in-loop approval interface
- [ ] Clear, warm language (avoid overwhelming data)
- [ ] Only show actionable items
- [ ] Protected tools badge/indicator

## Phase 5: Perplexity Integration
- [ ] Vendor cancellation policy research
- [ ] Refund precedent discovery
- [ ] Prorated refund calculation
- [ ] Alternative tool recommendations
- [ ] Market rate benchmarking

## Phase 6: Email Automation System
- [ ] Template management UI
- [ ] Variable substitution engine
- [ ] Batch email sending (Gmail MCP)
- [ ] Follow-up scheduling (3-day, 7-day)
- [ ] Response tracking and sentiment analysis

## Phase 7: Recovery Pipeline
- [ ] Outstanding payment tracking
- [ ] Contact history logging
- [ ] Automated follow-up sequences
- [ ] Attorney coalition health monitoring
- [ ] Risk zone tracking (green/yellow/red)

## Phase 8: Revenue Services Infrastructure
- [ ] Subscription audit service ($99-350/client)
- [ ] Legal document formatting service ($75-250/project)
- [ ] Gmail/Drive RAG intelligence ($200-500/setup)
- [ ] Client dashboard
- [ ] Payment processing

## Phase 9: Analytics & Reporting
- [ ] Monthly savings calculator
- [ ] ROI tracking dashboard
- [ ] Refund success rate tracking
- [ ] Revenue service metrics
- [ ] Annual impact projection

## Phase 10: Testing & Deployment
- [ ] Test Gmail MCP with real email data
- [ ] Verify protected tools filtering
- [ ] Test human approval workflow
- [ ] Integration tests for all MCP connectors
- [ ] Documentation and user guide

## Phase 1: Immediate Dashboard Build (Using Verified Data)
- [x] Analyze Capital One and Wells Fargo bank statements
- [x] Extract verified subscription list ($1,601/mo total)
- [ ] Seed database with verified subscription data
- [ ] Build trauma-informed audit dashboard UI
- [ ] Implement protected tools filter (MANUS, Otter, Scribd, Google Workspace, Claude, Perplexity, GitHub Copilot, Canva)
- [ ] Create human-in-loop approval interface
- [ ] Add confidence scoring for each recommendation
- [ ] Implement cost ranking (highest to lowest)
- [ ] Build cancellation email generator
- [ ] Add savings calculator


## Tonight's Final Task (Nov 7, 2025)
- [x] WARP AI subscription cancelled successfully
- [ ] Generate BLACKBOX cancellation + refund email
- [ ] Send BLACKBOX support request (email/form/ticket)
- [ ] Create comprehensive handoff document for tomorrow
- [ ] Sync status with Copilot, Perplexity, and Manus

## Tomorrow's Priorities
- [ ] Apple subscription audit at appleid.apple.com ($400/mo mystery charges)
- [ ] Google Workspace seat audit (remove 10 inactive users for $180/mo savings)
- [ ] Research PADDLE.NET APPBANTER service
- [ ] Cloudflare domain consolidation
- [ ] Netlify cancellation (keep Vercel)


## Phase 1: Immediate Dashboard Build (Using Verified Data)
- [x] Analyze Capital One and Wells Fargo bank statements
- [x] Extract verified subscription list ($1,601/mo total)
- [x] Seed database with verified subscription data (via UI instead)
- [x] Build trauma-informed audit dashboard UI
- [x] Implement protected tools filter (MANUS, Otter, Scribd, Google Workspace, Claude, Perplexity, GitHub Copilot, Canva)
- [x] Create human-in-loop approval interface
- [x] Add confidence scoring for each recommendation
- [x] Implement cost ranking (highest to lowest)
- [x] Build cancellation email generator (BLACKBOX ready)
- [x] Add savings calculator
- [x] Create comprehensive handoff document


## Tonight's Final Actions (Nov 7, 2025 - 4:50 AM)
- [x] Root cause analysis of BLACKBOX email failure
- [x] Discovered AI PDF myaidrive.com subscription ($39/month)
- [x] Verified BLACKBOX AI contact: blackboxapp@blackboxai.tech
- [x] Verified AI PDF contact: help@myaidrive.com
- [x] Created cancellation emails for both services
- [x] Implemented ironclad verification safeguards
- [ ] Send BLACKBOX AI cancellation email (user action)
- [ ] Send AI PDF cancellation email (user action)
- [ ] Set follow-up reminders for Nov 10 and Nov 14

## Immediate Savings Identified Tonight
- BLACKBOX AI: $14.97/month (eliminate 3 duplicates)
- AI PDF myaidrive.com: $39.00/month
- WARP AI: Cancelled successfully
- **Total: $53.97/month ($647.64/year)**
- **Refund potential: $64-114 one-time**


## ✅ EMAILS SENT - November 7, 2025, 4:55 AM PT

- [x] BLACKBOX AI cancellation email sent to blackboxapp@blackboxai.tech (Cc: gisele@blackbox.ai)
  - Message ID: 19a5dc635b53e833
  - Requested: Cancel 3 duplicate subscriptions + $25-75 refund
  - Follow-up: Check for response Nov 10, 2025

- [x] AI PDF myaidrive.com cancellation email sent to help@myaidrive.com
  - Message ID: 19a5dc67dce19a8e
  - Requested: Cancel subscription + $39 refund (same-day cancellation)
  - Follow-up: Check for response Nov 10, 2025

## Total Savings Locked In Tonight
- WARP AI: Cancelled (user completed)
- BLACKBOX AI: $14.97/month (pending confirmation)
- AI PDF myaidrive.com: $39.00/month (pending confirmation)
- **Total: $53.97/month ($647.64/year)**
- **Refund potential: $64-114 one-time**
