# BLACKBOX AI Cancellation + Refund Request

**Generated:** November 7, 2025, 4:20 AM PT  
**Issue:** Duplicate billing (3 subscriptions charged simultaneously)  
**Refund Amount:** $25-75 (estimated 3-6 months of duplicates)  
**Contact:** support@blackbox.ai

---

## Email Template (Copy-Paste Ready)

```
To: support@blackbox.ai
Subject: URGENT: Duplicate Subscription Charges + Refund Request

Hello BLACKBOX AI Support Team,

I am writing to report duplicate subscription charges on my Capital One Spark Miles card ending in 1078 and request immediate cancellation and refund.

ISSUE DETAILS:
I have been charged for THREE separate BLACKBOX AI subscriptions simultaneously, which appears to be a billing error or duplicate account issue.

Duplicate Charges Identified:
- October 16, 2025: $4.99 (charged 3 times on same day = $14.97 total)
- September 2025: $4.99 (charged 2 times = $9.98 total)
- Estimated total duplicate charges (last 3-6 months): $25-75

Account Information:
- Email: eric@recovery-compass.org
- Payment Method: Capital One Spark Miles card ending in 1078
- Service: BLACKBOX AI subscription

REQUESTED ACTIONS:
1. Cancel ALL active BLACKBOX AI subscriptions linked to my email and payment method immediately
2. Refund all duplicate charges from the last 6 months (maximum refund window)
3. Confirm in writing that:
   - All subscriptions have been cancelled
   - No future charges will occur
   - Refund amount and processing timeline

ADDITIONAL CONTEXT:
I have not actively used BLACKBOX AI in several months, and I was unaware that multiple subscriptions were running simultaneously. This appears to be a technical error on your billing system's end.

I am requesting this refund under your standard refund policy. Based on Reddit user reports (r/BlackboxAI_), your team has processed similar refund requests when contacted at support@blackbox.ai.

Please process this cancellation and refund within 7 business days and confirm via email.

If I do not receive a response within 7 days, I will:
1. Dispute the charges with Capital One (merchant dispute process)
2. Report the billing issue to my state's consumer protection agency
3. Leave reviews on relevant platforms regarding this billing experience

I prefer to resolve this directly with your team first.

Thank you for your prompt attention to this matter.

Best regards,
Eric Jones
eric@recovery-compass.org
Capital One Card ending in 1078
```

---

## Alternative: Cancel via Portal (If Email Fails)

**Steps:**
1. Go to: https://www.blackbox.ai/manage-subscriptions
2. Log in with: eric@recovery-compass.org
3. Navigate to: Billing Settings or Subscription Management
4. Click: "Cancel Subscription" for each active subscription
5. Screenshot confirmation page for records

**Note:** Based on Reddit reports, some users have difficulty finding the cancellation page. If you cannot locate it:
- Email support@blackbox.ai with subject "Cannot Find Cancellation Page - Need Assistance"
- Request direct cancellation link

---

## Refund Policy Research

**What I Found:**
- BLACKBOX AI mentions a "30-day money-back guarantee" in some contexts
- Reddit users report mixed success with refunds:
  - Some received refunds after emailing support@blackbox.ai
  - Others report delayed responses (7-14 days)
  - One user reported requesting refund 22 days ago with no response
- No official refund policy page found on blackbox.ai website

**Strategy:**
1. **First attempt:** Email support@blackbox.ai (most direct)
2. **If no response in 7 days:** Dispute with Capital One (merchant dispute)
3. **Leverage:** Mention duplicate billing error (strong case for refund)

---

## Expected Outcomes

**Best Case:**
- All 3 subscriptions cancelled within 24-48 hours
- Full refund of $50-75 processed within 7-14 business days
- Confirmation email with refund details

**Likely Case:**
- Subscriptions cancelled within 3-5 days
- Partial refund of $25-50 (last 3 months only)
- Response time: 5-10 business days

**Worst Case:**
- No response from support@blackbox.ai
- Must dispute with Capital One (30-60 day process)
- May only recover last 2 months of charges

---

## Capital One Dispute Backup Plan

**If BLACKBOX AI does not respond within 7 days:**

1. Call Capital One: 1-800-867-0904
2. Say: "I need to dispute duplicate merchant charges"
3. Provide:
   - Merchant: BLACKBOX SUBSCRIPTION
   - Dates: October 16, 2025 (3 charges of $4.99)
   - Reason: "Duplicate billing error - charged 3 times for same service"
   - Evidence: Email sent to support@blackbox.ai on Nov 7, 2025 (no response)

**Capital One will:**
- Issue temporary credit while investigating ($14.97 for October charges)
- Contact BLACKBOX AI on your behalf
- Resolve within 30-60 days

---

## Tracking & Follow-Up

**Action Items:**
- [ ] Send email to support@blackbox.ai (tonight)
- [ ] Set calendar reminder for Nov 14, 2025 (7 days) to check for response
- [ ] If no response by Nov 14, initiate Capital One dispute
- [ ] Screenshot all confirmation emails for records
- [ ] Update subscription audit dashboard with "Cancelled" status

**Estimated Savings:**
- Monthly: $14.97 (eliminating 3 duplicate charges)
- Refund: $25-75 (one-time recovery)
- Annual: $179.64 (if all duplicates stopped)

---

## Status: Ready to Send

**Next Step:** Copy the email template above and send to support@blackbox.ai right now.

**Confidence:** 85% (duplicate billing is clear error, strong case for refund)
