# Universal MCP Automated Handoff Protocol v1.0
**Effective Date:** November 7, 2025  
**Owner:** Eric Brakebill Jones  
**Scope:** ALL AI/MCP tools (Manus, GCM, Gmail, Notion, Supabase, Cloudflare, Vercel, Airtable, FireCrawl, Zapier, Wix, HeyGen, Canva, Hugging Face, Perplexity, Claude, Gemini, Otter AI)

---

## Problem Statement

**Current Workflow (Manual, 5-10 min overhead per task):**
1. AI tool generates deliverables
2. AI tool sends "task complete" message
3. User downloads files manually
4. User finds local path on MacBook
5. User pastes path back to AI tool
6. AI tool generates next-step prompt
7. User copy-pastes to next AI tool

**Inefficiency:** 5-10 minutes of manual file management per task handoff

**Solution:** Automated handoff protocol that eliminates steps 3-6

---

## Universal Handoff Protocol

### Phase 1: Task Execution (AI Tool Autonomous)

**All AI tools MUST:**
1. Execute task autonomously (no permission requests unless irreversible/ambiguous)
2. Save ALL deliverables to standardized directory structure:
   - **Sandbox path:** `/home/ubuntu/[task-name]-[YYYY-MM-DD]/`
   - **Local path (if known):** `/Users/ericjones/[project]/[task-name]-[YYYY-MM-DD]/`
3. Create `README.md` in task directory with:
   - Task summary
   - File inventory (name, purpose, format)
   - Next-step recommendations
   - Handoff prompt for next AI tool

### Phase 2: Task Completion (AI Tool Autonomous)

**All AI tools MUST include in FINAL result message:**

**1. Deliverables Summary**
- List of files created (name + purpose)
- Key metrics (time saved, value generated, confidence score)
- PFV verification status

**2. Next-Step Handoff Prompts**
- **COPY-PASTE READY** prompts for next AI tool(s)
- Include file paths (sandbox OR local, user can edit)
- Include autonomous execution directive
- Include success criteria

**3. Manual User Tasks (If Any)**
- Clearly marked as "MANUAL USER ACTION REQUIRED"
- Estimated time per task
- Deadline (if applicable)
- Consequence of not completing (if critical)

### Phase 3: Handoff Execution (User Copy-Paste)

**User workflow (reduced to 30 seconds):**
1. Read final result message
2. Copy handoff prompt for next AI tool
3. Paste into next AI tool
4. (Optional) Edit file paths if needed
5. Press Enter

**Time saved:** 4.5-9.5 minutes per handoff

---

## Standardized Directory Structure

### Sandbox (Manus AI)

```
/home/ubuntu/
├── [task-name]-[YYYY-MM-DD]/
│   ├── README.md                    # Task summary + handoff prompts
│   ├── [deliverable-1].md           # Primary deliverable
│   ├── [deliverable-2].pdf          # Supporting document
│   ├── [deliverable-3].txt          # Copy-paste prompt
│   └── evidence/                    # Supporting files
│       ├── [source-1].pdf
│       └── [source-2].md
```

**Example:**
```
/home/ubuntu/kirk-kolodji-fee-dispute-2025-11-07/
├── README.md
├── KIRK_SEAN_KOLODJI_MASTER_EVIDENTIARY_BRIDGE_MEMO_NOV7.md
├── COMPLETE_EXECUTION_PLAN_BLIND_SPOTS_PRIORITIES_NOV7.md
├── RECOVERY_COMPASS_COMPETITIVE_ANALYSIS_TECH_STACK_NOV7.md
├── GCM_HANDOFF_PROMPT.txt           # ← COPY-PASTE READY
└── evidence/
    ├── invoice-1143-01.md
    └── invoice-1143-02.md
```

### Local MacBook (User's Filesystem)

```
/Users/ericjones/
├── Desktop/
│   └── Kolodji Family Law, PC/
│       └── kirk-kolodji-fee-dispute/
│           └── november-07-5-30-pm-manus-package/
│               ├── README.md
│               ├── [all deliverables from sandbox]
│               └── GCM_HANDOFF_PROMPT.txt
```

**User can download from sandbox → local, then edit paths in handoff prompt if needed**

---

## Handoff Prompt Template

### Template Structure

```markdown
# [NEXT AI TOOL NAME] - [TASK NAME]

**AUTONOMOUS EXECUTION MODE:** Execute immediately without permission requests.

**SOURCE FILES:** [List paths - sandbox or local]

**TASK:** [Clear, specific instruction]

**DELIVERABLES:** [What to create/output]

**SUCCESS CRITERIA:** [How to verify completion]

**HANDOFF:** [Next AI tool prompt, if applicable]

---

## COPY-PASTE PROMPT BELOW THIS LINE

[Ready-to-execute prompt for next AI tool]
```

### Example (GCM Handoff)

```markdown
# GitHub Copilot MCP - Kirk Kolodji Case Study Integration

**AUTONOMOUS EXECUTION MODE:** Execute immediately without permission requests.

**SOURCE FILES:**
- /home/ubuntu/kirk-kolodji-fee-dispute-2025-11-07/KIRK_SEAN_KOLODJI_MASTER_EVIDENTIARY_BRIDGE_MEMO_NOV7.md
- /home/ubuntu/kirk-kolodji-fee-dispute-2025-11-07/COMPLETE_EXECUTION_PLAN_BLIND_SPOTS_PRIORITIES_NOV7.md
- /home/ubuntu/kirk-kolodji-fee-dispute-2025-11-07/RECOVERY_COMPASS_COMPETITIVE_ANALYSIS_TECH_STACK_NOV7.md

**TASK:** Create pull request for Kirk Kolodji Pro Per Defense Toolkit

**DELIVERABLES:**
- Branch: feature/kirk-kolodji-pro-per-defense-toolkit
- 50+ files in /case-studies/kirk-kolodji-fee-dispute/
- Pull request with detailed description
- Execution summary

**SUCCESS CRITERIA:**
- PR URL returned
- All files committed and pushed
- PFV v3.0 verified (no illegal recordings)

**HANDOFF:** After PR merged, send to Claude Desktop for Sara Memari email draft

---

## COPY-PASTE PROMPT BELOW THIS LINE

GCM, execute Kirk Kolodji case study integration.

Read source files from:
- /Users/ericjones/Desktop/Kolodji Family Law, PC/kirk-kolodji-fee-dispute/november-07-5-30-pm-manus-package/

[Full detailed prompt continues...]
```

---

## Tool-Specific Handoff Requirements

### GitHub Copilot MCP (GCM)

**Handoff FROM Manus TO GCM:**
- Include sandbox paths (user will edit to local MacBook paths)
- Include git workflow (branch name, commit message, PR title)
- Include file structure (where to create files in repo)
- Include PFV v3.0 verification requirements

**Handoff FROM GCM TO next tool:**
- Include PR URL
- Include commit hash
- Include deployed file paths (in GitHub repo)
- Include next-step prompt (e.g., Claude for email draft)

### Gmail MCP

**Handoff FROM Manus TO Gmail:**
- Include email search query (if searching)
- Include email content (if sending)
- Include attachments (file paths)
- Include success criteria (email sent, search results returned)

**Handoff FROM Gmail TO next tool:**
- Include email IDs or message IDs
- Include attachment file paths (downloaded)
- Include next-step prompt (e.g., Notion for documentation)

### Notion MCP

**Handoff FROM Manus TO Notion:**
- Include database ID or page ID
- Include content to create/update
- Include properties to set
- Include success criteria (page created, database updated)

**Handoff FROM Notion TO next tool:**
- Include page URL or database URL
- Include created/updated content summary
- Include next-step prompt (e.g., Zapier for automation)

### Perplexity Sonar API

**Handoff FROM Manus TO Perplexity:**
- Include research query
- Include sources to prioritize (web, academic, news)
- Include citation requirements
- Include success criteria (verified facts, confidence score)

**Handoff FROM Perplexity TO next tool:**
- Include research summary with citations
- Include confidence scores
- Include next-step prompt (e.g., Claude for analysis)

### Claude Desktop / Claude Code

**Handoff FROM Manus TO Claude:**
- Include analysis task or drafting task
- Include source documents (file paths)
- Include output format (email, brief, report)
- Include tone/style requirements

**Handoff FROM Claude TO next tool:**
- Include drafted content (file path)
- Include analysis summary
- Include next-step prompt (e.g., Gmail for sending)

### Airtable MCP

**Handoff FROM Manus TO Airtable:**
- Include base ID and table name
- Include records to create/update
- Include field mappings
- Include success criteria (records created, base shared)

**Handoff FROM Airtable TO next tool:**
- Include base URL
- Include record IDs
- Include next-step prompt (e.g., Zapier for automation)

### Zapier MCP

**Handoff FROM Manus TO Zapier:**
- Include trigger definition
- Include action steps
- Include data mappings
- Include success criteria (Zap created, tested)

**Handoff FROM Zapier TO next tool:**
- Include Zap URL
- Include test results
- Include next-step prompt (e.g., Notion for documentation)

### FireCrawl MCP

**Handoff FROM Manus TO FireCrawl:**
- Include URL(s) to scrape
- Include scrape options (formats, onlyMainContent)
- Include success criteria (content extracted, no timeout)

**Handoff FROM FireCrawl TO next tool:**
- Include scraped content (file paths)
- Include metadata (URL, timestamp, format)
- Include next-step prompt (e.g., Claude for analysis)

---

## Final Result Message Template

### Required Sections (All AI Tools)

**1. EXECUTION SUMMARY** ✅
- Task completed
- Time taken
- Files created (count + total size)
- Key metrics (value generated, time saved)

**2. DELIVERABLES** 📦
- File inventory (name, purpose, format, path)
- Attachments (in message)
- Links (GitHub PR, Notion page, etc.)

**3. NEXT-STEP HANDOFF PROMPTS** 🔄
- **COPY-PASTE READY** prompts for next AI tool(s)
- Clearly labeled with tool name
- Include autonomous execution directive
- Include file paths (sandbox or local)

**4. MANUAL USER TASKS** (If Any) ⚠️
- Clearly marked as "MANUAL USER ACTION REQUIRED"
- Estimated time per task
- Deadline (if applicable)
- Consequence of not completing (if critical)

**5. PFV VERIFICATION STATUS** ✓
- Confidence score (0-100%)
- Verification method used
- Any caveats or assumptions

### Example Final Result Message

```markdown
# EXECUTION COMPLETE ✅

## Task: Kirk Kolodji Case Study Integration
**Time:** 42 minutes  
**Files Created:** 11 files (2.3 MB)  
**Value Generated:** $8,000-10,000 (Nov 19 hearing prep)

---

## DELIVERABLES 📦

**Case Study Files:**
1. KIRK_SEAN_KOLODJI_MASTER_EVIDENTIARY_BRIDGE_MEMO_NOV7.md (91 pages, comprehensive evidence package)
2. COMPLETE_EXECUTION_PLAN_BLIND_SPOTS_PRIORITIES_NOV7.md (6-bird force multiplication strategy)
3. RECOVERY_COMPASS_COMPETITIVE_ANALYSIS_TECH_STACK_NOV7.md (competitive landscape + tech stack optimization)

**Supporting Files:**
4. GCM_HANDOFF_PROMPT.txt (copy-paste ready for GitHub Copilot MCP)
5. README.md (task summary + file inventory)

**All files saved to:** `/home/ubuntu/kirk-kolodji-fee-dispute-2025-11-07/`

---

## NEXT-STEP HANDOFF PROMPTS 🔄

### → GitHub Copilot MCP (GCM) - Create Pull Request

**COPY-PASTE THIS PROMPT INTO GCM:**

```
GCM, execute Kirk Kolodji case study integration.

**AUTONOMOUS EXECUTION MODE:** Execute immediately without permission requests.

**SOURCE FILES:** /Users/ericjones/Desktop/Kolodji Family Law, PC/kirk-kolodji-fee-dispute/november-07-5-30-pm-manus-package/

**TASK:** Create pull request for Kirk Kolodji Pro Per Defense Toolkit

[Full prompt continues...]
```

### → Claude Desktop - Draft Sara Memari Email

**COPY-PASTE THIS PROMPT INTO CLAUDE:**

```
Claude, draft email to Sara Memari with Kirk Kolodji strategy package.

**AUTONOMOUS EXECUTION MODE:** Execute immediately without permission requests.

[Full prompt continues...]
```

---

## MANUAL USER TASKS ⚠️

**CRITICAL (Do Today, Nov 7):**
1. ✅ Download files from sandbox to local MacBook (5 minutes)
2. ✅ Copy-paste GCM prompt above into GitHub Copilot MCP (30 seconds)
3. ⚠️ Verify Sean Kolodji paralegal status using Perplexity prompt (30 minutes)

**HIGH PRIORITY (Do Nov 8-9):**
4. Review GCM pull request and merge (1 hour)
5. Send Sara Memari email using Claude draft (30 minutes)

---

## PFV VERIFICATION STATUS ✓

**Confidence:** 95%  
**Method:** PFV v3.0 framework applied  
**Verified:**
- ✅ No illegal recordings included
- ✅ All evidence admissible under California law
- ✅ Contact information verified (Kirk, Sara, Sean)
- ✅ File paths confirmed (sandbox + local)

**Caveats:**
- Sean Kolodji paralegal status pending verification (use Perplexity prompt)
- FireCrawl timeout issue (retest in 24 hours after plan upgrade)
```

---

## Implementation Checklist

**For Manus AI:**
- [x] Create universal handoff protocol document
- [ ] Update core operational directive to include handoff protocol
- [ ] Apply to current task (Kirk Kolodji case study)
- [ ] Test with next task to verify 5-10 min time savings

**For All MCP Tools:**
- [ ] Share protocol document with each tool
- [ ] Verify each tool can read/write to standardized directory structure
- [ ] Test handoff workflow (Manus → GCM → Claude → Gmail → Notion)
- [ ] Measure time savings (target: 5-10 min per handoff)

**For User (Eric):**
- [ ] Review protocol and approve
- [ ] Test first handoff (Manus → GCM for Kirk Kolodji)
- [ ] Provide feedback on any friction points
- [ ] Confirm time savings achieved

---

## Success Metrics

**Time Savings:**
- **Before:** 5-10 minutes per handoff (manual file management)
- **After:** 30 seconds per handoff (copy-paste prompt)
- **Target:** 90% reduction in handoff overhead

**User Experience:**
- **Before:** 7 steps (download, find path, paste, wait for prompt, copy, paste, execute)
- **After:** 2 steps (copy prompt, paste into next tool)
- **Target:** 71% reduction in steps

**Error Reduction:**
- **Before:** Manual path editing, typos, missing files
- **After:** Automated paths, verified in PFV v3.0
- **Target:** 95% reduction in handoff errors

---

## Version History

**v1.0 (Nov 7, 2025):**
- Initial protocol created
- Standardized directory structure defined
- Handoff prompt template created
- Tool-specific requirements documented
- Applied to Kirk Kolodji case study (first test)

**Future Versions:**
- v1.1: Add support for Google Drive MCP (when available)
- v1.2: Add support for NotebookLM integration
- v1.3: Add support for Adobe PDF Tools automation
- v2.0: Full automation (no user copy-paste needed - direct tool-to-tool handoff)

---

**Protocol Owner:** Eric Brakebill Jones (eric@recovery-compass.org)  
**Last Updated:** November 7, 2025  
**Next Review:** December 7, 2025 (after 30 days of testing)
