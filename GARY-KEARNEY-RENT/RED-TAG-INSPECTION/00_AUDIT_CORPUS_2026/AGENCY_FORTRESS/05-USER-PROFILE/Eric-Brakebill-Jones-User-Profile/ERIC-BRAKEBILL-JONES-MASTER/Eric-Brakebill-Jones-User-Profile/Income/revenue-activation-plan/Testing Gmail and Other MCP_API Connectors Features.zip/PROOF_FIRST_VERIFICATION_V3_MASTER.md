├─ Multiple independent cross-references (2+ sources)
├─ Metadata + semantic content alignment
└─ [NEW] Single authoritative source with domain verification

TIER 3 (MODERATE - 70-84% confidence):
├─ Filename patterns (multiple files)
├─ Directory structure analysis
├─ Timestamp consistency
├─ Contextual inference from weak evidence
└─ [NEW] Inferred contact from payment receipts

TIER 4 (WEAK - 40-69% confidence):
├─ Single source only
├─ Logical inference without verification
├─ Assumption from incomplete data
├─ [NEW] Contact info from non-authoritative source (forums, etc.)
└─ Requires manual validation before use

TIER 5 (UNVERIFIED - 0-39% confidence):
├─ Speculation
├─ Assumption without supporting evidence
├─ [NEW] Contact information not independently verified
└─ ❌ DO NOT USE - Flagged for mandatory manual review
```

**Application Rule (v3.0 Universal Standard):**

| Data Type | Required Tier | Rationale |
|-----------|--------------|-----------|
| **Legal Status** (case filed, ruling, etc.) | TIER 1-2 | Critical decisions depend on accuracy |
| **Contact Information** (email, phone, address) | **TIER 1-2** | **[NEW]** Wasted effort if wrong, immediate impact |
| **Financial Data** (amounts, dates, accounts) | TIER 1-2 | Money at stake, high consequence |
| **Deadlines** (court dates, statute limitations) | TIER 1 | Missing deadline = case lost |
| **Simple Facts** (names, case numbers, titles) | **TIER 1-2** | **[NEW]** Foundation for complex analysis |
| **Background Context** (general project status) | TIER 3 | Lower consequence if approximate |
| **Speculative Analysis** (potential outcomes) | TIER 4-5 | Clearly labeled as uncertain |

**v3.0 Enhancement:** Contact information and simple facts elevated to TIER 1-2 requirement (previously assumed reliable without verification).

---

#### **Gate 2: Logic Gate (Enhanced v3.0)**

**Validation Requirements:**
1. Test strategic recommendations against legal authority (if applicable)
2. Identify logical fallacies or unsupported leaps
3. Reject conclusions that don't follow from verified premises
4. Analyze downstream consequences ("What could go wrong?")
5. Question assumptions ("What are we assuming that might not be true?")
6. **[NEW]** Verify simple fact chains (email → domain → vendor identity)

**Implementation:**
```python
def logic_gate_validation_v3(claim, premises, data_type):
    """
    v3.0: Applies logic validation to ALL data types, including simple facts
    """
    # Check premise → conclusion validity
    if not all_premises_support_conclusion(claim, premises):
        return {
            'status': 'FAILED',
            'reason': 'Conclusion does not follow from verified premises',
            'required_action': 'Provide additional supporting evidence or revise claim'
        }
    
    # [NEW] Simple fact chain validation
    if data_type in ['contact_info', 'simple_fact']:
        chain_valid = validate_fact_chain(claim, premises)
        if not chain_valid['valid']:
            return {
                'status': 'FAILED',
                'reason': f'Simple fact chain broken: {chain_valid["break_point"]}',
                'example': 'Email address → Domain ownership → Vendor identity',
                'required_action': 'Verify each link in chain independently'
            }
    
    # Check for logical fallacies
    fallacies = detect_fallacies(claim, premises)
    if fallacies:
        return {
            'status': 'WARNING',
            'fallacies_detected': fallacies,
            'recommendation': 'Reframe claim to avoid logical errors'
        }
    
    # Legal authority check (if applicable)
    if 'legal_context' in premises:
        authority_check = verify_legal_basis(claim, premises['legal_context'])
        if not authority_check['valid']:
            return {
                'status': 'FAILED',
                'reason': 'No legal authority supports this claim',
                'required_action': 'Cite legal statute, case law, or remove legal assertion'
            }
    
    return {'status': 'PASSED', 'confidence': 'HIGH'}

def validate_fact_chain(claim, premises):
    """
    [NEW v3.0] Validates simple fact chains for contact information
    Example: "support@vendor.com" requires:
      1. Domain "vendor.com" exists
      2. Domain owned by expected vendor
      3. Email pattern matches vendor's known format
      4. Cross-reference with other known vendor contacts
    """
    chain_links = extract_fact_chain(claim)
    
    for link in chain_links:
        if not verify_link(link, premises):
            return {
                'valid': False,
                'break_point': link,
                'recommendation': f'Independently verify: {link}'
            }
    
    return {'valid': True, 'confidence': 95}
```

---

#### **Gate 3: Confidence Gate (Enhanced v3.0)**

**Calibration Standards (Universal Application):**

| Label | Confidence | Evidence Required | Use Case | v3.0 Change |
|-------|-----------|-------------------|----------|-------------|
| ✅ VERIFIED | 95-100% | TIER 1 evidence, 2+ independent sources | Critical claims, legal status, **contact info** | **Contact info added** |
| 🔄 LIKELY | 85-94% | TIER 2 evidence, single authoritative source | Project status, timeline estimates | No change |
| ⚠️ UNCERTAIN | 70-84% | TIER 3 evidence, single weak source | Contextual background, requires verification | No change |
| ❓ UNVERIFIED | 40-69% | TIER 4 evidence, inference only | **Contact from forums**, speculation | **Contact degraded** |
| ❌ DO NOT USE | 0-39% | TIER 5 evidence, no verification | Flagged for manual review, excluded from briefings | No change |

**v3.0 Disclosure Requirements (Enhanced):**

**For ALL Data (not just complex claims):**
1. Confidence qualifier explicitly stated
2. Evidence tier cited with source
3. Source citations attorney-reviewable
4. Limitations acknowledged transparently
5. **[NEW]** Multi-source options when uncertain (hedging strategy)
6. **[NEW]** User alert when using inference vs. verification

**Example (Contact Information v3.0 Standard):**

**OLD (v2.0) - INSUFFICIENT:**
```
Email: support@blackbox.ai
```
